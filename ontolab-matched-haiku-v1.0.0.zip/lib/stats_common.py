"""Paired bootstrap shared by the stats_*.py scripts.
Units (documents, ontology pairs, facts, CQs) are resampled with replacement; both systems are
scored on the same resample, so the interval is for the DIFFERENCE and accounts for the pairing.
p = two-sided bootstrap p-value of the difference (share of resamples on the wrong side of 0, x2)."""
import numpy as np
B, SEED = 10000, 20261120
def paired(units, metric_a, metric_b, b=B, seed=SEED):
    """metric_x(list_of_units) -> float. Returns dict with point estimates, 95% CIs and p."""
    rng = np.random.default_rng(seed); n = len(units)
    a0, b0 = metric_a(units), metric_b(units)
    da, db, dd = [], [], []
    for _ in range(b):
        s = [units[i] for i in rng.integers(0, n, n)]
        x, y = metric_a(s), metric_b(s); da.append(x); db.append(y); dd.append(x - y)
    dd = np.array(dd); ci = lambda v: (float(np.percentile(v, 2.5)), float(np.percentile(v, 97.5)))
    p = 2 * min((dd <= 0).mean(), (dd >= 0).mean())
    return {"a": a0, "b": b0, "diff": a0 - b0, "ci_a": ci(da), "ci_b": ci(db), "ci_diff": ci(dd), "p": min(1.0, float(p)), "n": n}
def fmt(r, prec=3):
    f = lambda x: f"{x:.{prec}f}"
    p = "<0.001" if r["p"] < 0.001 else f"{r['p']:.3f}"
    return f"{f(r['a'])} [{f(r['ci_a'][0])}, {f(r['ci_a'][1])}] | {f(r['b'])} [{f(r['ci_b'][0])}, {f(r['ci_b'][1])}] | {r['diff']:+.{prec}f} [{r['ci_diff'][0]:+.{prec}f}, {r['ci_diff'][1]:+.{prec}f}] | {p}"
