"""Execute the frozen two-replicate plan with paired, counterbalanced arm order."""
import argparse
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import uuid

ROOT = Path(__file__).resolve().parent
WORK = ROOT.parent
TRACKS = WORK / "tracks" / "t2kb"
TSX = WORK / "ontolab-v4" / "node_modules" / ".bin" / "tsx"
ARMS = ("ontolab", "two-pass")


def run_pair(job, output, claude):
    rep, index, topic = job
    arms = ARMS if (index + rep) % 2 == 0 else ARMS[::-1]
    ok = True
    for arm in arms:
        target = output / f"r{rep}" / arm / topic
        if (target / "predictions.json").exists():
            continue
        target.mkdir(parents=True, exist_ok=True)
        with (target / f"attempt-{uuid.uuid4().hex}.log").open("w") as log:
            result = subprocess.run(
                [str(TSX), str(ROOT / "run.mts"), arm, str(rep), topic, claude, str(output)],
                cwd=WORK, stdout=log, stderr=subprocess.STDOUT, timeout=900, check=False,
            )
        status = "complete" if result.returncode == 0 else "failed"
        ok &= result.returncode == 0
        print(f"r{rep} {topic} {arm} {status}", flush=True)
    return ok


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--workers", type=int, default=6)
    args = parser.parse_args()
    topics = sorted(x.name for x in TRACKS.iterdir() if (x / "doc.txt").is_file())
    assert len(topics) == 19
    output = ROOT / "results"
    output.mkdir(exist_ok=True)
    frozen = {topic: {name: hashlib.sha256((TRACKS / topic / name).read_bytes()).hexdigest()
                      for name in ("doc.txt", "tbox.ttl", "sentences.json")} for topic in topics}
    manifest = output / "input-sha256.json"
    if manifest.exists():
        if json.loads(manifest.read_text()) != frozen:
            raise ValueError("Study inputs changed")
    else:
        manifest.write_text(json.dumps(frozen, indent=2) + "\n")
    jobs = [(rep, index, topic) for rep in (1, 2) for index, topic in enumerate(topics)]
    claude = shutil.which("claude")
    if not claude:
        raise ValueError("Claude Code is unavailable")
    with ThreadPoolExecutor(max_workers=args.workers) as pool:
        results = list(pool.map(lambda job: run_pair(job, output, claude), jobs))
    print(f"{sum(results)}/{len(jobs)} pairs completed", flush=True)
    return 0 if all(results) else 1


if __name__ == "__main__":
    sys.exit(main())
