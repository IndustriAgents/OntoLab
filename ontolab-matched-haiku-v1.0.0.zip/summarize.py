"""Replay quality and native Claude Code cost for the matched-citation experiment."""
import argparse
import collections
import json
from pathlib import Path
import re
import statistics
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parent
WORK = ROOT.parent
sys.path.insert(0, str(ROOT / "lib" if (ROOT / "lib").is_dir() else WORK / "converters"))
from stats_common import paired, fmt  # noqa: E402

ARMS = ("ontolab", "two-pass")
FIELDS = ("input_tokens", "cache_creation_input_tokens", "cache_read_input_tokens", "output_tokens")


def read(path):
    return json.loads(path.read_text())


def canonical(item, lenient):
    sub, rel, obj = (item[k] for k in ("sub", "rel", "obj"))

    def loosen(value):
        tail_removed = re.sub(r"_?\([^()]*\)\s*$", "", value.strip()).strip()
        return re.sub(r"^(\d+)\.0$", r"\1", tail_removed)
    if lenient:
        sub, obj = loosen(sub), loosen(obj)
    return tuple(re.sub(r'[_\s"]', "", part).lower() for part in (sub, rel, obj))


def counts(triples, gold, lenient):
    found = {canonical(x, lenient) for x in triples}
    reference = {canonical(x, lenient) for x in gold}
    cited = {canonical(x, lenient) for x in triples if x["spans"]}
    return len(found & reference), len(found), len(reference), len(cited)


def metrics(rows, index):
    true, found, gold, cited = [sum(x[index][i] for x in rows) for i in range(4)]
    return {
        "Precision": true / found if found else 0,
        "Recall": true / gold if gold else 0,
        "F1": 2 * true / (found + gold) if found + gold else 0,
        "Located citation coverage": cited / found if found else 0,
    }


def metered(folder):
    calls = folder / "calls"
    started = {read(p)["id"] for p in calls.glob("*.start.json")}
    totals = collections.Counter({key: 0 for key in FIELDS})
    missing, usage_calls, errors = 0, 0, 0
    cost, api_seconds = 0.0, 0.0
    models = set()
    for call in sorted(started):
        f = calls / f"{call}.end.json"
        end = read(f) if f.is_file() else {}
        result = end.get("result") or {}
        usage = result.get("usage") or {}
        models.update(end.get("models") or [])
        models.update((result.get("modelUsage") or {}).keys())
        errors += bool(result.get("is_error")) or end.get("exit_code") not in (0, None)
        if any(not isinstance(usage.get(key), int) for key in FIELDS):
            missing += 1
            continue
        if not isinstance(result.get("total_cost_usd"), (int, float)) or not isinstance(result.get("duration_api_ms"), (int, float)):
            raise ValueError(f"Usage is present but cost or API duration missing: {f}")
        totals.update({key: usage[key] for key in FIELDS})
        usage_calls += 1
        cost += result["total_cost_usd"]
        api_seconds += result["duration_api_ms"] / 1000
    return dict(totals, calls=len(started), usage_calls=usage_calls, unmetered=missing,
                errors=errors, usd=cost, api_seconds=api_seconds, models=sorted(models))


def official(rep_dirs, tracks):
    with tempfile.TemporaryDirectory(prefix="ontolab-matched-eval-") as tmp:
        run = Path(tmp)
        for pred in rep_dirs:
            entry = read(pred)
            (run / (entry["track"] + ".json")).write_text(json.dumps(dict(entry, config="matched-quote")))
        subprocess.run([str(WORK / ".venv" / "bin" / "python"), "-I", str(WORK / "converters" / "t2kb_score.py"),
                        str(tracks), str(run), str(WORK / "datasets" / "text2kgbench" / "repo")],
                       check=True, stdout=subprocess.DEVNULL)
        output = read_jsonl(run / "official-all" / "avg.jsonl")
    return output[-1]["avg_f1"]


def read_jsonl(path):
    return [json.loads(line) for line in path.read_text().splitlines() if line.strip()]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--replicates", nargs="+", type=int, default=[1, 2])
    parser.add_argument("--results", type=Path, default=ROOT / "results")
    parser.add_argument("--tracks", type=Path, default=WORK / "tracks" / "t2kb")
    parser.add_argument("--no-official", action="store_true")
    args = parser.parse_args()
    topics = sorted(p.name for p in args.tracks.iterdir() if (p / "sentences.json").exists())
    assert len(topics) == 19
    log = {arm: [] for arm in ARMS}
    by_topic = {topic: [] for topic in topics}
    print("# Matched-citation Haiku results\n")
    for rep in args.replicates:
        print(f"## Replicate {rep}\n")
        print("| Arm | Whole-graph P | R | Lenient F1 | Strict F1 | Official sentence F1 | Located-citation coverage |")
        print("|---|---:|---:|---:|---:|---:|---:|")
        rep_values = {arm: [] for arm in ARMS}
        for arm in ARMS:
            files = []
            for topic in topics:
                folder = args.results / f"r{rep}" / arm / topic
                path = folder / "predictions.json"
                data = read(path)
                files.append(path)
                gold = [triple for sent in read(args.tracks / topic / "sentences.json") for triple in sent["triples"]]
                triples = data["triples"]
                totals = metered(folder)
                if totals["models"] != ["claude-haiku-5-5"]:
                    raise ValueError(f"Unexpected model in {folder}: {totals['models']}")
                rep_values[arm].append([counts(triples, gold, le) for le in (True, False)])
                log[arm].append(dict(totals, wall=data["seconds"]))
            rows = rep_values[arm]
            result, strict = metrics(rows, 0), metrics(rows, 1)
            sentence = "—" if args.no_official else f"{float(official(files, args.tracks)):.3f}"
            print(f"| {arm} | {result['Precision']:.3f} | {result['Recall']:.3f} | {result['F1']:.3f} | "
                  f"{strict['F1']:.3f} | {sentence} | {result['Located citation coverage']:.3f} |")
        for i, topic in enumerate(topics):
            by_topic[topic].append(tuple(rep_values[arm][i] for arm in ARMS))
        print()
    print("## Paired bootstrap over topics\n")
    print("Replicates for a topic travel together. Confidence intervals condition on the observed runs.\n")
    print("| Metric | OntoLab [95% CI] | Two-pass [95% CI] | Difference [95% CI] | p |")
    print("|---|---:|---:|---:|---:|")
    for key, normalization in [("F1", 0), ("Precision", 0), ("Recall", 0), ("F1", 1), ("Located citation coverage", 0)]:
        def score(groups, arm):
            return metrics([pair[arm] for group in groups for pair in group], normalization)[key]
        result = paired(list(by_topic.values()), lambda groups: score(groups, 0), lambda groups: score(groups, 1))
        label = key + (" (strict)" if normalization else "")
        print(f"| {label} | {fmt(result)} |")
    print("\n## Cost per document\n")
    print("Token and API-equivalent USD estimates are means across document runs. Wall times are medians for the successful workflow executions under concurrency. "
          "Incomplete attempts are included when usage was emitted. Unmetered attempts are counted separately.\n")
    print("| Arm | Docs | Invocation count | Unmetered | Uncached input | Cache writes | Cache reads | Output | Total tokens | API-equiv. USD | API s | Wall s |")
    print("|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|")
    for arm, records in log.items():
        means = {key: statistics.mean(r[key] for r in records) for key in (*FIELDS, "usd", "api_seconds")}
        tokens = sum(means[key] for key in FIELDS)
        values = " | ".join(f"{means[key]:,.0f}" for key in FIELDS)
        print(f"| {arm} | {len(records)} | {sum(r['calls'] for r in records)} | {sum(r['unmetered'] for r in records)} | {values} | "
              f"{tokens:,.0f} | {means['usd']:.4f} | {means['api_seconds']:.1f} | {statistics.median(r['wall'] for r in records):.1f} |")


if __name__ == "__main__":
    main()
