# Matched-citation Haiku benchmark

Install Python 3.11 or 3.12 and NumPy 1.26.4. From this archive's root run:

    python3 summarize.py --tracks tracks --no-official

This recomputes graph metrics, located citation coverage, clustered intervals and the native CLI metering from frozen predictions. The archived SUMMARY.md also reports official sentence F1 using the upstream evaluator and the original tagged sentences. The raw source sentences and copied quotations are omitted here. The complete inference design is in DESIGN.md.

Reference facts are derived from [Text2KGBench DBpedia-WebNLG](https://github.com/cenguix/Text2KGBench), by Nandana Mihindukulasooriya, Sanju Tiwari, Carlos F. Enguix and Kavitha Srinivas, with data from [WebNLG 3.0](https://gitlab.com/shimorina/webnlg-dataset) under CC BY-NC-SA 4.0. See the project repositories for attributions and upstream terms. The historical experiment code uses the v4 snapshot (OntoLab commit 3931d33 plus experiment patches).
