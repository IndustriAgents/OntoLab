import "../converters/offline-models.mts";
import { chmod, copyFile, mkdir, mkdtemp, readFile, rename, writeFile } from "node:fs/promises";
import { join, resolve } from "node:path";
import { tmpdir } from "node:os";
import { fileURLToPath } from "node:url";
import { execFileSync } from "node:child_process";
import type { EvidenceRef } from "../ontolab-v4/src/types/abox.ts";

const root = fileURLToPath(new URL("./", import.meta.url));
const [arm, replicate, track, binaryArg, outputArg] = process.argv.slice(2);
if (!["ontolab", "two-pass"].includes(arm) || !replicate || !track || !binaryArg || !outputArg)
  throw new Error("Usage: run.mts ontolab|two-pass REPLICATE TOPIC REAL_CLAUDE RESULTS_ROOT");
const realBinary = resolve(binaryArg);
const out = join(resolve(outputArg), "r" + replicate, arm, track);
await mkdir(out, { recursive: true });
const metered = join(out, "meter-claude.py");
await copyFile(join(root, "meter-claude.py"), metered);
await chmod(metered, 0o755);
await writeFile(join(out, "meter-config.json"), JSON.stringify({ binary: realBinary }));
Object.assign(process.env, {
  ONTOLAB_CLAUDE_BIN: metered, LOCAL_CLI_ENABLED: "1", EMBEDDINGS_BACKEND: "local",
  NLI_BACKEND: "local", NLI_LOCAL_MODEL: "Xenova/nli-deberta-v3-xsmall", NLI_REVIEW_THRESHOLD: "0.35",
  REUSE_SOURCES: "", DATA_DIR: await mkdtemp(join(tmpdir(), "ontolab-matched-haiku-")),
});
const cliVersion = execFileSync(realBinary, ["--version"], { encoding: "utf8" }).trim();
const { locateQuote } = await import("../ontolab-v4/server/services/evidence.ts");
const local = (uri: string) => uri.replace(/^.*[#/]/, "");
type Sentence = { id: string; sent: string };
type Span = { start: number; end: number };
type Triple = { sub: string; rel: string; obj: string; sentences: string[]; quotes: string[]; spans: Span[] };
type Proposal = { sub: string; rel: string; obj: string; quote: string; moreQuotes?: string[] };
const input = join(root, "..", "tracks", "t2kb", track);
const text = await readFile(join(input, "doc.txt"), "utf8");
const tbox = await readFile(join(input, "tbox.ttl"), "utf8");
const rows: Sentence[] = JSON.parse(await readFile(join(input, "sentences.json"), "utf8"));
const provider = "claude-cli";
const model = "haiku";
const allowed = [...tbox.matchAll(/^:([^\s]+) a owl:(?:DatatypeProperty|ObjectProperty)\b/gm)].map((m) => m[1]);

function attach(sub: string, rel: string, obj: string, quotes: string[], spans: Span[], source: string): Triple {
  const sentences = rows.flatMap((row) => {
    const span = locateQuote(row.sent, source);
    return span && spans.some((quote) => quote.start < span.end && quote.end > span.start) ? [row.id] : [];
  });
  return { sub, rel, obj, sentences, quotes, spans };
}

async function twoPass(): Promise<{ triples: Triple[]; priorCount: number }> {
  const { callStructured } = await import("../ontolab-v4/server/structured.ts");
  const schema = {
    type: "object", required: ["triples"], additionalProperties: false, properties: {
      triples: { type: "array", items: {
        type: "object", required: ["sub", "rel", "obj", "quote"], additionalProperties: false, properties: {
          sub: { type: "string" }, rel: { type: "string", enum: allowed }, obj: { type: "string" },
          quote: { type: "string", minLength: 1 }, moreQuotes: { type: "array", maxItems: 3, items: { type: "string" } },
        },
      } },
    },
  };
  const system = "Extract the unique relation assertions stated in this document that the ontology can express. " +
    "Use only its properties and respect domain and range. Use source names and literal values and resolve co-referring mentions. " +
    "For every assertion copy a short verbatim quote that explicitly states that subject, relation and object. " +
    "If several sentences state the assertion, put the first in quote and up to three other verbatim sentences in moreQuotes. " +
    "Do not duplicate assertions.";
  const lead = `Ontology:\n${tbox}\n\nDocument:\n${text}`;
  const opts = { provider, model, schema, toolName: "emit_triples", toolDesc: "Unique assertions with verbatim evidence" };
  const first = await callStructured({ ...opts, system, lead });
  const second = await callStructured({
    ...opts, system: system + " Review the draft against the source. Add missed assertions, correct mistakes and quotes, " +
      "remove unsupported assertions, and return the entire revised graph.",
    lead: `${lead}\n\nDraft:\n${JSON.stringify(first.data.triples)}`,
  });
  const triples = (second.data.triples as Proposal[]).map(({ sub, rel, obj, quote, moreQuotes }) => {
    const quotes = [quote, ...(moreQuotes ?? [])];
    const spans = quotes.flatMap((q) => locateQuote(q, text) ?? []);
    return attach(sub, rel, obj, quotes, spans, text);
  });
  return { triples, priorCount: (first.data.triples as Proposal[]).length };
}

async function ontolab(): Promise<{ triples: Triple[]; skipped: number }> {
  const { createLocalStore } = await import("../ontolab-v4/server/store/local.ts");
  const { silentLogger } = await import("../ontolab-v4/server/services/context.ts");
  const projects = await import("../ontolab-v4/server/services/projects.ts");
  const documents = await import("../ontolab-v4/server/services/documents.ts");
  const revisions = await import("../ontolab-v4/server/services/revisions.ts");
  const runs = await import("../ontolab-v4/server/services/runs.ts");
  const { applyMergeDecisions } = await import("../ontolab-v4/src/lib/ontology/resolution.ts");
  const { stopSparqlPool } = await import("../ontolab-v4/server/services/sparqlPool.ts");
  const user = { id: "eval" };
  const store = createLocalStore(process.env.DATA_DIR!).forUser(user);
  const ctx = { store, user, now: () => new Date(), log: silentLogger, requestId: track };
  try {
    const project = await projects.createProject(ctx, { name: track, purpose: `Extract facts about ${track} from sentences`, scope: "" });
    const document = await documents.uploadDocument(ctx, project.id, "doc.txt", Buffer.from(text));
    const source = (await store.documents.getText(project.id, document.id))?.text;
    if (!source) throw new Error("Document parser returned no source text");
    const version = await revisions.createRevision(ctx, project.id, {
      content: { modules: [{ id: "t2kb", name: "tbox.ttl", turtle: tbox }], abox: null, baseIri: "" }, source: "import",
      summary: "Text2KGBench T-Box",
    });
    await revisions.commitRevision(ctx, project.id, version.id);
    let run = await runs.createRun(ctx, project.id, {
      kind: "extraction", documentIds: [document.id], mode: "automatic", provider, model,
      options: { grounding: [], schemaRetrieval: "force", verifyEvidence: true, evidenceGate: "flag" },
    });
    for (let i = 0; i < 20000; i++) {
      const step = await runs.advanceRun(ctx, project.id, run.id);
      run = step.run;
      if (["ready_for_review", "failed", "cancelled", "awaiting_answers"].includes(run.status)) break;
      if (step.waitMs) await new Promise((done) => setTimeout(done, Math.min(step.waitMs!, 5000)));
    }
    if (run.status !== "ready_for_review") throw new Error(`Run ended ${run.status}: ${run.error ?? ""}`);
    const draft = await revisions.requireRevision(ctx, project.id, run.resultRevisionId!);
    const merged = applyMergeDecisions(draft.content.abox ?? { individuals: [] }, draft.content.resolution?.candidates ?? []);
    const labels = new Map(merged.individuals.map((ind) => [ind.id, ind.label ?? ind.id]));
    const triples: Triple[] = [];
    function add(sub: string, rel: string, obj: string, evidence: EvidenceRef[] = []) {
      const spans = evidence.flatMap((ref) => {
        if (ref.check && ref.check.backend !== "local-Xenova/nli-deberta-v3-xsmall") throw new Error("Local NLI fallback");
        return ref.status === "verified" && ref.start != null && ref.end != null ? [{ start: ref.start, end: ref.end }] : [];
      });
      triples.push(attach(sub, rel, obj, evidence.map((ref) => ref.quote), spans, source!));
    }
    for (const ind of merged.individuals) {
      const subject = ind.label ?? ind.id;
      for (const d of ind.dataProperties ?? []) add(subject, local(d.propUri), d.value, d.evidence);
      for (const o of ind.objectProperties ?? []) add(subject, local(o.propUri), labels.get(o.targetId) ?? o.targetId, o.evidence);
    }
    return { triples, skipped: run.skipped ?? 0 };
  } finally {
    await stopSparqlPool().catch(() => {});
  }
}

const started = Date.now();
try {
  const data = await (arm === "ontolab" ? ontolab() : twoPass());
  const result = { arm, track, replicate, provider, model, cliVersion, seconds: (Date.now() - started) / 1000, ...data };
  await writeFile(join(out, "predictions.tmp"), JSON.stringify(result, null, 2) + "\n");
  await rename(join(out, "predictions.tmp"), join(out, "predictions.json"));
  console.log(arm, track, data.triples.length, "triples", result.seconds.toFixed(2), "seconds");
} catch (error) {
  console.error(arm, track, error instanceof Error ? error.message : error);
  process.exitCode = 1;
}
