#!/usr/bin/env python3
"""Forward Claude Code unchanged and retain usage-only metadata for each inference."""
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import uuid


def write(path, data):
    temp = path.with_suffix(".tmp")
    temp.write_text(json.dumps(data) + "\n")
    os.replace(temp, path)


def main():
    folder = Path(__file__).resolve().parent
    config = json.loads((folder / "meter-config.json").read_text())
    args = sys.argv[1:]
    binary = config["binary"]
    if "-p" not in args:
        os.execv(binary, [binary, *args])
    output = folder / "calls"
    output.mkdir(exist_ok=True)
    call_id = uuid.uuid4().hex
    start = time.monotonic()
    write(output / f"{call_id}.start.json", {"id": call_id, "started_unix": time.time()})
    child = subprocess.Popen([binary, *args], stdout=subprocess.PIPE)
    result = None
    model_ids = []
    for line in child.stdout:
        try:
            event = json.loads(line)
            if event.get("type") == "system" and event.get("subtype") == "init" and event.get("model"):
                model_ids.append(event["model"])
            if event.get("type") == "result":
                result = {key: event.get(key) for key in ("usage", "modelUsage", "total_cost_usd", "duration_api_ms",
                                                           "num_turns", "is_error", "subtype")}
        except (ValueError, AttributeError):
            pass
        sys.stdout.buffer.write(line)
        sys.stdout.buffer.flush()
    exit_code = child.wait()
    write(output / f"{call_id}.end.json", {
        "id": call_id, "exit_code": exit_code, "wall_seconds": time.monotonic() - start,
        "models": model_ids, "result": result,
    })
    return exit_code


if __name__ == "__main__":
    sys.exit(main())
