"""Paper figures, rebuilt from experiments/results (CPU only, a few seconds).

usage (from the paper folder): <python with numpy+matplotlib> figures/make_figures.py
  fig-grounding.pdf  caught share vs false-alarm rate, own citation vs best sentence anywhere
  fig-t2kb.pdf       Text2KGBench DBpedia precision / recall / F1, OntoLab vs direct, three models
"""
import json, os, re
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

HERE = os.path.dirname(os.path.abspath(__file__))
RES = os.path.join(HERE, "..", "..", "experiments", "results")
plt.rcParams.update({"font.size": 8, "font.family": "serif", "axes.spines.top": False, "axes.spines.right": False,
                     "pdf.fonttype": 42})
C_ONTO, C_BASE = "#1f5fa8", "#c9792b"  # colour-blind-safe blue / orange


def curve(pos, neg, fa):
    """share of corrupted facts (neg) caught at each false-alarm rate on correct facts (pos)."""
    return [float((neg < np.percentile(pos, 100 * f)).mean()) for f in fa]


def fig_grounding():
    fa = np.linspace(0.0, 0.2, 81)
    fig, axes = plt.subplots(1, 2, figsize=(4.8, 1.9), sharey=True)
    for ax, s in zip(axes, ("gemini", "haiku")):
        R = [json.loads(l) for l in open(os.path.join(RES, "27-grounding", f"inject-object-{s}-ontolab.jsonl")) if l.strip()]
        U = np.array([[r["origCited"], r["swapCited"], r["origAny"], r["swapAny"]] for r in R])
        ax.plot(fa, curve(U[:, 0], U[:, 1], fa), color=C_ONTO, label="own citation (OntoLab)")
        ax.plot(fa, curve(U[:, 2], U[:, 3], fa), color=C_BASE, ls="--", label="best sentence anywhere")
        ax.axvline(0.05, color="0.6", lw=0.6, ls=":")
        ax.set_title(f"facts from {'Gemini' if s == 'gemini' else 'Haiku'} (n={len(U)})", fontsize=8)
        ax.set_xlabel("false alarms on correct facts")
        ax.set_xlim(0, 0.2); ax.set_ylim(0, 1)
    axes[0].set_ylabel("wrong-object facts caught")
    axes[1].legend(loc="lower right", frameon=False, fontsize=7)
    fig.tight_layout(pad=0.3)
    fig.savefig(os.path.join(HERE, "fig-grounding.pdf"))


def fig_t2kb():
    rows = {}
    for line in open(os.path.join(RES, "28-stats-t2kb.md")):
        m = re.match(r"\| (OntoLab\+(Gemini v4|Haiku v4|GPT Luna v4)) vs (\S+(?: \S+)?) direct \(n=19\) \| (\w+) \| ([\d.]+) \[([\d.]+), ([\d.]+)\] \| ([\d.]+) \[([\d.]+), ([\d.]+)\]", line)
        if m:
            model = m.group(2).replace(" v4", "").replace("GPT ", "")
            rows[(model, m.group(4))] = [float(x) for x in m.group(5, 6, 7, 8, 9, 10)]
    models, metrics = ["Gemini", "Haiku", "Luna"], ["Precision", "Recall", "F1"]
    fig, axes = plt.subplots(1, 3, figsize=(4.8, 1.8), sharey=True)
    x = np.arange(len(models)); w = 0.36
    for ax, met in zip(axes, metrics):
        for k, (lab, col, off) in enumerate((("OntoLab", C_ONTO, -w / 2), ("direct prompt", C_BASE, w / 2))):
            v = np.array([rows[(mo, met)][3 * k] for mo in models])
            lo = np.array([rows[(mo, met)][3 * k + 1] for mo in models]); hi = np.array([rows[(mo, met)][3 * k + 2] for mo in models])
            ax.bar(x + off, v, w, color=col, label=lab, yerr=[v - lo, hi - v], error_kw={"lw": 0.6, "capsize": 1.5})
        ax.set_xticks(x, models); ax.set_title(met, fontsize=8); ax.set_ylim(0, 0.85)
    axes[0].set_ylabel("lenient, whole graph")
    h, l = axes[0].get_legend_handles_labels()
    fig.legend(h, l, loc="upper center", frameon=False, fontsize=7, ncol=2)
    fig.tight_layout(pad=0.3, rect=(0, 0, 1, 0.9))
    fig.savefig(os.path.join(HERE, "fig-t2kb.pdf"))


if __name__ == "__main__":
    fig_grounding(); fig_t2kb(); print("figures written to", HERE)
