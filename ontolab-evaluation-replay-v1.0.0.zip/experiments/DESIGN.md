# Experiment design

Goal: evaluate OntoLab (ontology-guided extraction with evidence verification) on public benchmarks, against the
same LLM used without OntoLab and against published baselines, with several model vendors.

## Studies

| # | Study | Benchmark (units) | OntoLab task | Baselines | Metric |
|---|---|---|---|---|---|
| S1 | Extraction | Text2KGBench DBpedia-WebNLG test, 19 ontologies × 25 sentences | A-Box extraction with T-Box retrieval + evidence gate (`grids/study3-kg.json`, config `retrieval+evidence`) | same model, direct prompt (`t2kb_direct.mts`) | whole-graph P/R/F1 (strict and lenient; official per-sentence also reported) |
| S1h | Held-out extraction | Text2KGBench Wikidata-TekGen *verified* (250 sents) and *unseen* (170) | as S1 | as S1 | as S1 |
| S1a | Ablations | as S1 | full-tbox-no-gate, edc-retrieval, retrieval+evidence+auto-accept (tree-prompt: invalid, not rerun) | full config | ΔF1 |
| S2 | Alignment | OAEI Conference ra1-M3 (21 pairs), MSE (3) | lexical+semantic candidates, LLM verification | edna, StringEquiv (official), OAEI participants | F1 |
| S3 | Evidence gate | ContractNLI | NLI entailment gate | NLI models of other sizes | pass rates |
| S4 | Grounding | S1 outputs + injected errors (subject, relation, object, number) | citation-anchored NLI | best-sentence-anywhere NLI | AUROC, caught@5% false alarm |
| S5 | Taxonomy induction | OLLM arXiv (eval split for HP, test split) | induction + pruning (OLLM weighting) | OLLM prompting baseline | literal/fuzzy/continuous/graph F1 |
| S6 | CQ-driven ontology generation | Lippolis et al. ESWC 2025, 3 domains × 15 CQs (protected) | induction from story + CQs (default, n-ary) | published Ontogenia / memless CQbyCQ ontologies | CQ coverage by LLM judges (cross-vendor) + human rating; OOPS-style pitfalls |

Models (via local CLIs, `ONTOLAB_VERSION.md`): Gemini 3.8 Flash low (main), Claude Haiku, GPT-6 Luna medium.
Judges for S6: Gemini 3.8 Flash medium, GPT-6.1 Terra medium, Claude Sonnet 4.6; a system is scored only by judges
from other vendors.

Statistics: paired bootstrap over units (topics, pairs, facts, CQs), 10,000 resamples, seed 20261120; 95% CI on the
difference; two-sided p. Headline tests listed in `results/28-STATS-SUMMARY.md` (Holm over them). Variance across
runs: 3 runs per system for S1 (Haiku, Luna) and S2.

## Amendments (dated; append, do not edit)

- **2026-11-20** Pinned clone at `3e8ce2b`; two harness/product bugs fixed in the clone (OAEI reference loader, local NLI text pair). Grid configs without a model always score 0 (relation "candidate"): excluded.
- **2026-11-20** Haiku files ordinary facts as proposed terms → fix (PR #44, proposed-facts folding); S1 rerun on code v4 for all models.
- **2026-11-20** Embedding tokenizer load race → silent hash fallback (PR #44). OLLM runs before it are invalid (`*-HASHFALLBACK-invalid`).
- **2026-11-20 21:05** Runners re-downloaded models per run; network drops caused silent embedder/NLI fallbacks. `converters/offline-models.mts` forbids downloads. Affected runs set aside (`results/28-STATS-SUMMARY.md` §Model-loading fallback). Rule: grep logs for `unavailable` before trusting a run.
- **2026-11-21** Third model: gpt-oss-120b dropped (quota), replaced by GPT-6 Luna via codex CLI. Second/third judges: GPT-6.1 Terra (codex) and Claude Sonnet 4.6 (claude CLI); scoring is cross-vendor only. No more agy runs for new work.
- **2026-11-21** Held-out set: raw TekGen gold is distant supervision → use the *verified* and *unseen* subsets only (`T2KB_SELECT`).
- **2026-11-21** GPT-6 Luna returns empty extractions at random (low and medium effort). PR #45 (retry empty extraction once, note it) applied to copies v4/v5; all Luna runs restarted at **medium** effort; earlier Luna results kept as `*-luna-low-INVALID-empty-extractions`.

- **2026-11-21, revision follow-up**: replay the grounding comparison with a paired topic bootstrap (same
  5th-percentile operating point, 10,000 draws). Audit sentence coverage and conservative full-date
  normalisation on saved outputs. Add an exploratory same-model document-level comparator on DBpedia-WebNLG:
  one extraction call and one self-review call in the same CLI, a full T-Box, a relation enum, and source
  sentence IDs. Score every proposed fact before any human decisions and report observed usage. This design
  controls task granularity and the output vocabulary and measures rather than assumes budget parity.
  See `docs/HUMAN-STUDY.md` for the separate human validation protocol.
  The document-review run used the Haiku alias via Claude Code 2.1.330 and the original DBpedia-WebNLG
  topics. All 19 topics completed. It has one model run per topic and should be interpreted as an
  exploratory comparison, with topic resampling conditional on the run.
