# Extraction diagnostics

## Haiku sentence attribution

Strict here retains the benchmark harness's case, underscore, quote and whitespace normalisation.

| Run | Sentences | Sentences with predictions | Unique matched triples | Match attributed to a gold sentence | Matches with multiple predicted IDs | Mean per-sentence F1 |
|---|---:|---:|---:|---:|---:|---:|
| OntoLab | 469 | 306 | 211 | 210 | 24 | 0.195 |
| Direct | 469 | 463 | 230 | 227 | 132 | 0.364 |

## TekGen sensitivity to full-date formatting

The same rules apply to reference and predicted object values. Year-only and ambiguous numeric dates retain their original precision.

| Model | Subset | Run | Main F1 | With date normalisation |
|---|---|---|---:|---:|
| Haiku | verified | ontolab | 0.410 | 0.413 |
| Haiku | verified | direct | 0.431 | 0.433 |
| Haiku | unseen | ontolab | 0.300 | 0.300 |
| Haiku | unseen | direct | 0.357 | 0.357 |
| Luna | verified | ontolab | 0.270 | 0.273 |
| Luna | verified | direct | 0.415 | 0.418 |
| Luna | unseen | ontolab | 0.299 | 0.299 |
| Luna | unseen | direct | 0.349 | 0.349 |
