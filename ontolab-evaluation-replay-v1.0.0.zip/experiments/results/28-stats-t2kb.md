# Text2KGBench DBpedia-WebNLG test: paired bootstrap over documents (10,000 resamples)

Whole-graph corpus metrics, lenient matching. A failed document (no output) counts as 0 predicted facts for that system.

| Comparison | Metric | A [95% CI] | B [95% CI] | A - B [95% CI] | p |
|---|---|---|---|---|---|
| OntoLab+Gemini v3 vs Gemini direct (n=19) | F1 | 0.641 [0.574, 0.705] | 0.489 [0.398, 0.573] | +0.152 [+0.089, +0.222] | <0.001 |
| OntoLab+Gemini v3 vs Gemini direct (n=19) | Precision | 0.729 [0.659, 0.793] | 0.458 [0.365, 0.549] | +0.271 [+0.191, +0.352] | <0.001 |
| OntoLab+Gemini v3 vs Gemini direct (n=19) | Recall | 0.572 [0.501, 0.642] | 0.523 [0.427, 0.616] | +0.048 [-0.007, +0.108] | 0.091 |
| OntoLab+Gemini v4 vs Gemini direct (n=19) | F1 | 0.641 [0.578, 0.703] | 0.489 [0.398, 0.573] | +0.152 [+0.094, +0.221] | <0.001 |
| OntoLab+Gemini v4 vs Gemini direct (n=19) | Precision | 0.701 [0.635, 0.765] | 0.458 [0.365, 0.549] | +0.242 [+0.169, +0.322] | <0.001 |
| OntoLab+Gemini v4 vs Gemini direct (n=19) | Recall | 0.591 [0.524, 0.658] | 0.523 [0.427, 0.616] | +0.067 [+0.013, +0.129] | 0.012 |
| OntoLab+Haiku v4 vs Haiku direct (n=19) | F1 | 0.561 [0.497, 0.623] | 0.500 [0.432, 0.564] | +0.061 [+0.006, +0.120] | 0.028 |
| OntoLab+Haiku v4 vs Haiku direct (n=19) | Precision | 0.639 [0.567, 0.708] | 0.472 [0.399, 0.546] | +0.166 [+0.103, +0.230] | <0.001 |
| OntoLab+Haiku v4 vs Haiku direct (n=19) | Recall | 0.501 [0.436, 0.565] | 0.532 [0.456, 0.603] | -0.031 [-0.086, +0.028] | 0.318 |
| OntoLab+Gemini v3 vs OntoLab+Gemini v4 (n=19) | F1 | 0.641 [0.574, 0.705] | 0.641 [0.578, 0.703] | -0.000 [-0.024, +0.027] | 0.937 |
| OntoLab+Gemini v3 vs OntoLab+Gemini v4 (n=19) | Precision | 0.729 [0.659, 0.793] | 0.701 [0.635, 0.765] | +0.028 [-0.003, +0.061] | 0.077 |
| OntoLab+Gemini v3 vs OntoLab+Gemini v4 (n=19) | Recall | 0.572 [0.501, 0.642] | 0.591 [0.524, 0.658] | -0.019 [-0.048, +0.013] | 0.243 |
| OntoLab+Haiku v4 vs OntoLab+Haiku v3 (n=19) | F1 | 0.561 [0.497, 0.623] | 0.446 [0.328, 0.550] | +0.115 [+0.047, +0.199] | <0.001 |
| OntoLab+Haiku v4 vs OntoLab+Haiku v3 (n=19) | Precision | 0.639 [0.567, 0.708] | 0.563 [0.429, 0.685] | +0.076 [+0.007, +0.159] | 0.026 |
| OntoLab+Haiku v4 vs OntoLab+Haiku v3 (n=19) | Recall | 0.501 [0.436, 0.565] | 0.370 [0.261, 0.471] | +0.131 [+0.052, +0.224] | <0.001 |
| OntoLab+GPT Luna v4 vs GPT Luna direct (n=19) | F1 | 0.594 [0.542, 0.641] | 0.505 [0.432, 0.574] | +0.089 [+0.041, +0.139] | <0.001 |
| OntoLab+GPT Luna v4 vs GPT Luna direct (n=19) | Precision | 0.657 [0.605, 0.710] | 0.465 [0.385, 0.546] | +0.192 [+0.135, +0.245] | <0.001 |
| OntoLab+GPT Luna v4 vs GPT Luna direct (n=19) | Recall | 0.542 [0.480, 0.601] | 0.553 [0.476, 0.624] | -0.010 [-0.059, +0.041] | 0.717 |
