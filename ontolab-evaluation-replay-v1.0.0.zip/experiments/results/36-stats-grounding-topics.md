# Grounding injection: paired bootstrap over topics (10,000 resamples)

All original/corrupted pairs in a sampled topic travel together. The 5th percentile is recalculated for each check and draw.

| Facts from | Corruption | Metric | Own citation [95% CI] | Anywhere [95% CI] | Difference [95% CI] | p |
|---|---|---|---|---|---|---|
| Gemini | object (n=299, topics=19) | AUROC | 0.979 [0.966, 0.990] | 0.903 [0.849, 0.947] | +0.075 [+0.037, +0.121] | <0.001 |
| Gemini | object (n=299, topics=19) | caught @5% FA | 0.923 [0.890, 0.961] | 0.719 [0.545, 0.839] | +0.204 [+0.098, +0.380] | <0.001 |
| Gemini | subject (n=316, topics=19) | AUROC | 0.894 [0.843, 0.937] | 0.889 [0.838, 0.932] | +0.005 [+0.001, +0.010] | 0.024 |
| Gemini | subject (n=316, topics=19) | caught @5% FA | 0.633 [0.498, 0.803] | 0.661 [0.490, 0.809] | -0.028 [-0.057, +0.029] | 1.000 |
| Gemini | relation (n=316, topics=19) | AUROC | 0.921 [0.885, 0.948] | 0.923 [0.885, 0.951] | -0.002 [-0.008, +0.002] | 0.383 |
| Gemini | relation (n=316, topics=19) | caught @5% FA | 0.557 [0.369, 0.750] | 0.601 [0.378, 0.767] | -0.044 [-0.125, +0.043] | 0.874 |
| Gemini | number (n=100, topics=17) | AUROC | 0.994 [0.982, 1.000] | 0.994 [0.979, 1.000] | +0.000 [-0.004, +0.005] | 1.000 |
| Gemini | number (n=100, topics=17) | caught @5% FA | 0.980 [0.846, 1.000] | 0.980 [0.875, 1.000] | +0.000 [-0.074, +0.010] | 1.000 |
| Haiku | object (n=268, topics=19) | AUROC | 0.987 [0.975, 0.996] | 0.909 [0.859, 0.954] | +0.078 [+0.039, +0.121] | <0.001 |
| Haiku | object (n=268, topics=19) | caught @5% FA | 0.955 [0.869, 0.984] | 0.698 [0.556, 0.874] | +0.257 [+0.096, +0.379] | <0.001 |
| Haiku | subject (n=280, topics=19) | AUROC | 0.911 [0.862, 0.954] | 0.909 [0.859, 0.952] | +0.002 [-0.009, +0.015] | 0.687 |
| Haiku | subject (n=280, topics=19) | caught @5% FA | 0.693 [0.483, 0.829] | 0.675 [0.549, 0.834] | +0.018 [-0.192, +0.050] | 0.974 |
| Haiku | relation (n=280, topics=19) | AUROC | 0.924 [0.888, 0.952] | 0.928 [0.904, 0.950] | -0.004 [-0.021, +0.009] | 0.592 |
| Haiku | relation (n=280, topics=19) | caught @5% FA | 0.604 [0.310, 0.784] | 0.621 [0.487, 0.794] | -0.018 [-0.221, +0.046] | 0.347 |
| Haiku | number (n=88, topics=17) | AUROC | 0.993 [0.982, 1.000] | 0.991 [0.974, 0.999] | +0.003 [-0.003, +0.010] | 0.493 |
| Haiku | number (n=88, topics=17) | caught @5% FA | 0.977 [0.873, 1.000] | 0.966 [0.868, 1.000] | +0.011 [-0.034, +0.046] | 1.000 |
