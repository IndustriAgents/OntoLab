# Text2KGBench DBpedia-WebNLG test: paired bootstrap over documents (10,000 resamples)

Whole-graph corpus metrics, lenient matching. A failed document (no output) counts as 0 predicted facts for that system.

| Comparison | Metric | A [95% CI] | B [95% CI] | A - B [95% CI] | p |
|---|---|---|---|---|---|
| OntoLab Haiku vs Haiku document review (n=19) | F1 | 0.561 [0.497, 0.623] | 0.575 [0.510, 0.635] | -0.014 [-0.054, +0.025] | 0.491 |
| OntoLab Haiku vs Haiku document review (n=19) | Precision | 0.639 [0.567, 0.708] | 0.612 [0.534, 0.690] | +0.027 [-0.015, +0.072] | 0.241 |
| OntoLab Haiku vs Haiku document review (n=19) | Recall | 0.501 [0.436, 0.565] | 0.542 [0.481, 0.599] | -0.041 [-0.084, -0.002] | 0.041 |
| Haiku document review vs Haiku sentence direct (n=19) | F1 | 0.575 [0.510, 0.635] | 0.500 [0.432, 0.564] | +0.075 [+0.023, +0.130] | 0.005 |
| Haiku document review vs Haiku sentence direct (n=19) | Precision | 0.612 [0.534, 0.690] | 0.472 [0.399, 0.546] | +0.140 [+0.069, +0.212] | <0.001 |
| Haiku document review vs Haiku sentence direct (n=19) | Recall | 0.542 [0.481, 0.599] | 0.532 [0.456, 0.603] | +0.010 [-0.030, +0.057] | 0.664 |
# Model cost per document: paired runs (Text2KGBench DBpedia-WebNLG, up to 25 sentences per document)

Mean per document (median in brackets). Ratio = first system / second system, of the means.

| System | docs | input tokens | output tokens | total tokens | seconds | ratio total tokens | ratio seconds |
|---|---|---|---|---|---|---|---|
| Haiku document review | 19 | 3,202 [3,516] | 17,308 [17,106] | 20,511 [20,488] | 69 [67] | 1.2x | 0.4x |
| OntoLab Haiku | 19 | 3,552 [3,025] | 13,656 [13,456] | 17,208 [15,218] | 191 [56] | | |
