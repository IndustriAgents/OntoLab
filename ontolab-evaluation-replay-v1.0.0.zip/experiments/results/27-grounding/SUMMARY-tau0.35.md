# Grounding and review effort (Text2KGBench DBpedia-WebNLG test, lenient gold matching, NLI threshold 0.35)

| System | Facts | Precision | Precision counting name-form near misses | Supported by a source sentence | Own citation entails it | P if supported | P if unsupported |
|---|---|---|---|---|---|---|---|
| OntoLab + Gemini | 454 | 0.729 | 0.815 | 0.98 | 0.97 | 0.734 | 0.545 |
| Gemini direct | 661 | 0.458 | 0.563 | 0.98 | — (no citations) | 0.461 | 0.357 |
| OntoLab + Haiku | 454 | 0.639 | 0.736 | 0.97 | 0.95 | 0.645 | 0.417 |
| Haiku direct | 652 | 0.472 | 0.564 | 0.98 | — (no citations) | 0.477 | 0.200 |

## Review simulation: share of wrong facts found after checking the first k% (least trusted first)

| System | Order | AUROC | 10% | 20% | 30% | 50% | Check until rest >= 90% correct |
|---|---|---|---|---|---|---|---|
| OntoLab + Gemini | post-hoc NLI | 0.66 | 0.16 | 0.37 | 0.48 | 0.63 | 0.95 |
| OntoLab + Gemini | own signal | 0.62 | 0.15 | 0.30 | 0.45 | 0.61 | 0.95 |
| OntoLab + Gemini | random | 0.52 | 0.09 | 0.17 | 0.30 | 0.54 | 0.93 |
| Gemini direct | post-hoc NLI | 0.54 | 0.12 | 0.24 | 0.33 | 0.52 | 1.00 |
| Gemini direct | random | 0.45 | 0.08 | 0.18 | 0.27 | 0.47 | 1.00 |
| OntoLab + Haiku | post-hoc NLI | 0.68 | 0.16 | 0.37 | 0.46 | 0.66 | 0.95 |
| OntoLab + Haiku | own signal | 0.64 | 0.13 | 0.27 | 0.45 | 0.64 | 0.95 |
| OntoLab + Haiku | random | 0.51 | 0.08 | 0.20 | 0.32 | 0.49 | 1.00 |
| Haiku direct | post-hoc NLI | 0.59 | 0.14 | 0.27 | 0.37 | 0.56 | 1.00 |
| Haiku direct | random | 0.52 | 0.09 | 0.20 | 0.31 | 0.52 | 1.00 |
