// Two-pass document-level baseline. Run with tsx and pass the experiment work directory.
import { mkdir, readdir, readFile, writeFile } from "node:fs/promises";
import { join, resolve } from "node:path";
import { pathToFileURL } from "node:url";

const [work, tracks, output, provider, model, only] = process.argv.slice(2);
if (!model) throw new Error("usage: tsx t2kb_document_review.mts WORKDIR TRACKS OUTPUT PROVIDER MODEL [TOPIC]");
const { callStructured } = await import(pathToFileURL(resolve(work, "ontolab-v4/server/structured.ts")).href);
const topics = (await readdir(tracks, { withFileTypes: true }))
  .filter(entry => entry.isDirectory() && (!only || entry.name === only))
  .map(entry => entry.name).sort();
if (!topics.length) throw new Error("No benchmark topics selected");
await mkdir(output, { recursive: true });

type Triple = { sub: string; rel: string; obj: string; sentences: string[] };
type Sentence = { id: string; sent: string };

for (const track of topics) {
  const ontology = JSON.parse(await readFile(join(tracks, track, "ontology.json"), "utf8"));
  const sentences: Sentence[] = JSON.parse(await readFile(join(tracks, track, "sentences.json"), "utf8"));
  const relationNames: string[] = ontology.relations.map((r: { label: string }) => r.label.replace(/ /g, "_"));
  const sentenceIds = sentences.map(row => row.id);
  const tbox = await readFile(join(tracks, track, "tbox.ttl"), "utf8");
  const schema = {
    type: "object",
    required: ["triples"],
    additionalProperties: false,
    properties: {
      triples: {
        type: "array",
        items: {
          type: "object",
          required: ["sub", "rel", "obj", "sentences"],
          additionalProperties: false,
          properties: {
            sub: { type: "string" },
            rel: { type: "string", enum: relationNames },
            obj: { type: "string" },
            sentences: { type: "array", minItems: 1, items: { type: "string", enum: sentenceIds } },
          },
        },
      },
    },
  };
  const lead = [
    `Ontology:\n${tbox}`,
    `Document:\n${sentences.map(row => `[${row.id}] ${row.sent}`).join("\n\n")}`,
  ].join("\n\n");
  const options = { provider, model, schema, toolName: "emit_triples", toolDesc: "Unique document triples with evidence sentence IDs" };
  const extract = "Extract the unique facts stated in this document that the ontology can express. " +
    "Respect domain and range and use only its relations. Use the source names and literal values, " +
    "resolve co-referring mentions, and cite all sentence IDs that state each fact.";
  const start = Date.now();
  try {
    const initial = await callStructured({ ...options, system: extract, lead });
    const reviewed = await callStructured({
      ...options,
      system: extract + " Review the supplied draft against the document. Add missed facts, correct inaccurate facts, " +
        "remove unsupported facts, and return the entire revised graph.",
      lead: `${lead}\n\nDraft:\n${JSON.stringify(initial.data.triples)}`,
    });
    const triples = (reviewed.data.triples as Triple[]).filter(triple =>
      relationNames.includes(triple.rel) && triple.sentences.length && triple.sentences.every(id => sentenceIds.includes(id)),
    );
    const usagePerCall = [initial.usage, reviewed.usage];
    const usage = Object.fromEntries(Object.keys({ ...initial.usage, ...reviewed.usage }).map(key =>
      [key, usagePerCall.reduce((total, entry) => total + (entry[key] ?? 0), 0)],
    ));
    await writeFile(join(output, `${track}.json`), JSON.stringify({
      track, provider, model, config: "document-review", seconds: (Date.now() - start) / 1000,
      usage, usagePerCall, initialTriples: initial.data.triples, triples,
    }, null, 1) + "\n");
    console.log(`${track}: ${triples.length} reviewed triples`);
  } catch (error) {
    console.error(`${track}: ${error instanceof Error ? error.message : error}`);
    process.exitCode = 1;
  }
}
