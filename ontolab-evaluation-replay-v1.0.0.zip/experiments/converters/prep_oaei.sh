#!/bin/bash
# Builds eval track folders (source.owl, target.owl, reference.rdf) from the downloaded
# OAEI Conference (ra1, 21 pairs) and MSE (3 test cases) data.
set -euo pipefail
ROOT=$(cd "$(dirname "$0")/.." && pwd)
C=$ROOT/datasets/oaei-conference; M=$ROOT/datasets/mse/repo/testCases
OUT_C=$ROOT/tracks/conference; OUT_M=$ROOT/tracks/mse
rm -rf "$OUT_C" "$OUT_M"; mkdir -p "$OUT_C" "$OUT_M"
onto() { case "$1" in conference) echo Conference.owl;; *) echo "$1.owl";; esac; }
for r in "$C"/ref/*.rdf; do
  pair=$(basename "$r" .rdf); a=${pair%%-*}; b=${pair#*-}
  d=$OUT_C/$pair; mkdir -p "$d"
  cp "$C/raw/$(onto "$a")" "$d/source.owl"; cp "$C/raw/$(onto "$b")" "$d/target.owl"; cp "$r" "$d/reference.rdf"
done
mk() { mkdir -p "$OUT_M/$1"; cp "$M/$2/$3" "$OUT_M/$1/source.owl"; cp "$M/$2/$4" "$OUT_M/$1/target.owl"; cp "$M/$2/$5" "$OUT_M/$1/reference.rdf"; }
mk mse1-MI-reduced_MatOnto firstTestCase MaterialInformation-Reduced.owl MatOnto.owl RefAlign1.rdf
mk mse2-MI_MatOnto secondTestCase MaterialInformation.owl MatOnto.owl RefAlign2.rdf
mk mse3-MI_EMMO thirdTestCase MaterialInformation.owl EMMO-merged.owl RefAlign3.rdf
ls "$OUT_C" | wc -l; ls "$OUT_M"
