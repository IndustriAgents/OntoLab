"""Rebuild paper statistics from recorded outputs, without model calls."""
import argparse
import hashlib
import io
import json
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path

EXPERIMENTS = Path(__file__).resolve().parents[1]
CONVERTERS = EXPERIMENTS / "converters"
RESULTS = EXPERIMENTS / "results"
GEMINI = "24-t2kb-v4/retrieval+evidence"
GEMINI_DIRECT = "07-t2kb-direct-gemini-3.8-flash-low"
MODELS = (
    ("Haiku", "23-haiku/t2kb-ontolab-v4", "23-haiku/t2kb-direct", "34-haiku"),
    ("Luna", "30-luna/t2kb-ontolab", "30-luna/t2kb-direct", "35-luna"),
)


def spec(name, run):
    return f"{name}={RESULTS / run}"


def fetch_archive(name, checksum):
    url = f"https://oaei.ontologymatching.org/2023/conference/data/{name}"
    data = subprocess.check_output(["curl", "-fsSL", "--retry", "2", "--max-time", "30", url])
    if hashlib.sha256(data).hexdigest() != checksum:
        raise ValueError(f"Unexpected OAEI archive checksum: {name}")
    return zipfile.ZipFile(io.BytesIO(data))


def prepare_conference(root):
    ontologies = fetch_archive("conference.zip", "78688cda05857b594be188db6831abc5d890d2e38d6602e0cd8d3c82ecb24546")
    aligns = fetch_archive("reference-alignment.zip", "782e0175253d817288e1f7ed29f738a7fa9e57a8b9c77bb3b11c12b80405d4bf")
    with ontologies, aligns:
        owl = {Path(name).stem.lower(): name for name in ontologies.namelist() if name.lower().endswith(".owl")}
        rdf = [name for name in aligns.namelist() if name.lower().endswith(".rdf") and not Path(name).name.startswith("._")]
        if len(rdf) != 21:
            raise ValueError(f"Expected 21 OAEI pairs, found {len(rdf)}")
        for name in rdf:
            pair = Path(name).stem
            left, right = pair.lower().split("-")
            dest = root / pair
            dest.mkdir(parents=True)
            (dest / "source.owl").write_bytes(ontologies.read(owl[left]))
            (dest / "target.owl").write_bytes(ontologies.read(owl[right]))
            (dest / "reference.rdf").write_bytes(aligns.read(name))
    return root


def prepare_text_tracks(root, snapshot, expected):
    gold_files = sorted(snapshot.glob("*_gt.jsonl"))
    if len(gold_files) != expected:
        raise ValueError(f"Expected {expected} gold topics in {snapshot}, found {len(gold_files)}")
    for path in gold_files:
        topic = root / path.name.removesuffix("_gt.jsonl")
        topic.mkdir(parents=True)
        rows = [json.loads(line) for line in path.read_text().splitlines() if line.strip()]
        (topic / "sentences.json").write_text(json.dumps(rows), encoding="utf-8")
    return root


def capture(name, *args):
    return subprocess.check_output([sys.executable, "-I", str(CONVERTERS / name), *map(str, args)], text=True)


def official_extraction():
    runs = [("Gemini OntoLab", GEMINI), ("Gemini direct", GEMINI_DIRECT)]
    for name, full, direct, _ in MODELS:
        runs.extend([(f"{name} OntoLab", full), (f"{name} direct", direct)])
    runs.append(("Haiku document review", "36-document-review-haiku"))
    lines = ["# Official Text2KGBench per-sentence scores from saved evaluator output",
             "", "| Run | P | R | F1 |", "|---|---:|---:|---:|"]
    for name, run in runs:
        path = RESULTS / run / "official-all" / "avg.jsonl"
        if not path.is_file() and name == "Luna OntoLab":
            path = RESULTS / run / "official-all-lenient" / "avg.jsonl"
        global_score = json.loads(path.read_text().splitlines()[-1])
        lines.append(f"| {name} | {global_score['avg_precision']} | {global_score['avg_recall']} | {global_score['avg_f1']} |")
    return "\n".join(lines) + "\n"


def taxonomy_summary():
    rows = (
        ("Gemini", "20-ollm-arxiv/ontolab-weighted", "20-ollm-arxiv/prompting"),
        ("Haiku", "23-haiku/ollm-ontolab-weighted", "23-haiku/ollm-prompting"),
        ("Luna", "30-luna/ollm-ontolab-weighted", "30-luna/ollm-prompting"),
    )
    keys = ("fuzzy_f1", "continuous_f1", "graph_f1")

    def scores(run):
        metrics = json.loads((RESULTS / run / "metrics.json").read_text())["test"]
        return " / ".join(f"{metrics[key]:.3f}" for key in keys)

    lines = ["# OLLM saved test scores (fuzzy / continuous / graph F1)", "",
             "| Model | OntoLab | Direct |", "|---|---|---|"]
    for name, full, direct in rows:
        lines.append(f"| {name} | {scores(full)} | {scores(direct)} |")
    return "\n".join(lines) + "\n"


def replay(root, output, conference):
    db = prepare_text_tracks(root / "dbpedia", RESULTS / GEMINI_DIRECT / "official-all", 19)
    comparisons = [
        spec("OntoLab+Gemini v3", "17-t2kb-v3/retrieval+evidence"), spec("Gemini direct", GEMINI_DIRECT),
        spec("OntoLab+Gemini v4", GEMINI), spec("Gemini direct", GEMINI_DIRECT),
    ]
    details = []
    cost = [f"Gemini={RESULTS / GEMINI}|{RESULTS / GEMINI_DIRECT}"]
    for name, full, direct, extra in MODELS:
        comparisons.extend([spec(f"OntoLab+{name}", full), spec(f"{name} direct", direct)])
        cost.append(f"{name}={RESULTS / full}|{RESULTS / direct}")
        for subset in ("verified", "unseen"):
            prefix = f"{extra}/tekgen-{subset}"
            snapshot = RESULTS / f"{prefix}-direct" / "official-all"
            heldout = prepare_text_tracks(root / f"{name}-{subset}", snapshot, 10)
            stats = capture("stats_t2kb.py", heldout, spec("OntoLab", f"{prefix}-ontolab"), spec("Direct", f"{prefix}-direct"))
            details.append(f"## {name}, TekGen {subset}\n\n{stats}")
        ablations = ("full-tbox-no-gate", "edc-retrieval", "retrieval+evidence+auto-accept")
        args = [item for config in ablations for item in (spec("Full", full), spec(config, f"{extra}/ablation-{config}"))]
        details.append(f"## {name}, ablations\n\n{capture('stats_t2kb.py', db, *args)}")
        repeat_dirs = [f"{extra}/repeat-ontolab-r{run}" for run in (2, 3)]
        direct_dirs = [f"{extra}/repeat-direct-r{run}" for run in (2, 3)]
        repeat_stats = capture("stats_repeats.py", db, spec("OntoLab", full) + "," + ",".join(str(RESULTS / p) for p in repeat_dirs),
                               spec("Direct", direct) + "," + ",".join(str(RESULTS / p) for p in direct_dirs))
        details.append(f"## {name}, repeats\n\n{repeat_stats}")
        cost.append(f"{name}, retrieval only={RESULTS / extra / 'ablation-edc-retrieval'}|{RESULTS / direct}")

    revised = "36-document-review-haiku"
    if len(list((RESULTS / revised).glob("[0-9]*.json"))) == 19:
        comparisons.extend([spec("OntoLab+Haiku v4", MODELS[0][1]), spec("Haiku document review", revised)])
        cost.append(f"Haiku document review vs OntoLab Haiku={RESULTS / revised}|{RESULTS / MODELS[0][1]}")

    tables = {
        "extraction.md": capture("stats_t2kb.py", db, *comparisons),
        "extraction-details.md": "\n".join(details),
        "extraction-audit.md": capture("audit_extraction.py"),
        "official-sentence-scores.md": official_extraction(),
        "taxonomy.md": taxonomy_summary(),
        "grounding.md": capture("stats_grounding.py", RESULTS / "27-grounding"),
        "cost.md": capture("stats_cost.py", *cost),
    }
    if conference is not False:
        official = conference or prepare_conference(root / "conference")
        align = [
            spec("OntoLab + Gemini verification", "08-align-verify-gemini-3.8-flash-low/lss-verify.json"),
            spec("OntoLab + Haiku verification", "23-haiku/align-verify.json"),
            spec("OntoLab + Luna verification", "30-luna/align-verify.json"),
        ]
        for name, _, _, folder in MODELS:
            align.extend(spec(f"OntoLab + {name} verification r{r}", f"{folder}/align-verify-r{r}.json") for r in (2, 3))
        tables["alignment.md"] = capture("stats_oaei.py", official, RESULTS / "02-align-matchers", *align)

    output.mkdir(parents=True, exist_ok=True)
    for name, content in tables.items():
        (output / name).write_text(content, encoding="utf-8")
        print(output / name)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=EXPERIMENTS / "build" / "replay")
    source = parser.add_mutually_exclusive_group()
    source.add_argument("--conference", type=Path, help="Use existing OAEI Conference tracks from setup.sh")
    source.add_argument("--offline", action="store_true", help="Replay the extraction and grounding tables offline")
    args = parser.parse_args()
    with tempfile.TemporaryDirectory(prefix="ontolab-replay-") as work:
        replay(Path(work), args.output, False if args.offline else args.conference)


if __name__ == "__main__":
    main()
