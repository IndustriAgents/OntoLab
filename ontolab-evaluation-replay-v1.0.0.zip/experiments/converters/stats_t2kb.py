"""Text2KGBench (DBpedia-WebNLG test), corpus-level whole-graph P/R/F1 with lenient matching (the same
normalisation as t2kb_score.py --lenient), paired bootstrap over the 19 documents.
usage: python3 -I stats_t2kb.py <tracks/t2kb> "<label A>=<run dir A>" "<label B>=<run dir B>" [...more pairs as A,B,A,B]
"""
import glob, json, os, re, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from stats_common import paired, fmt
tracks, *specs = sys.argv[1:]
def nt(a, b, c):
    L = lambda x: re.sub(r"^(\d+)\.0$", r"\1", re.sub(r"_?\((?:[^()]*)\)\s*$", "", x.strip()).strip())
    return "|".join(re.sub(r"(_|\s+|\")", "", x).lower() for x in (L(a), b, L(c)))
def counts(run):
    out = {}
    for f in glob.glob(os.path.join(run, "*.json")):
        if f.endswith(".error.json") or os.path.basename(f).startswith("SUMMARY"): continue
        r = json.load(open(f))
        if "track" not in r: continue
        gold = {nt(t["sub"], t["rel"], t["obj"]) for s in json.load(open(os.path.join(tracks, r["track"], "sentences.json"))) for t in s["triples"]}
        pred = {nt(t["sub"], t["rel"], t["obj"]) for t in r["triples"]}
        out[r["track"]] = (len(pred & gold), len(pred), len(gold))
    return out
def f1(cs):
    tp, pr, gd = (sum(c[i] for c in cs) for i in range(3)); P = tp / pr if pr else 0; R = tp / gd if gd else 0
    return 2 * P * R / (P + R) if P + R else 0
def prec(cs):
    tp, pr = sum(c[0] for c in cs), sum(c[1] for c in cs); return tp / pr if pr else 0
def rec(cs):
    tp, gd = sum(c[0] for c in cs), sum(c[2] for c in cs); return tp / gd if gd else 0
print("# Text2KGBench DBpedia-WebNLG test: paired bootstrap over documents (10,000 resamples)\n")
print("Whole-graph corpus metrics, lenient matching. A failed document (no output) counts as 0 predicted facts for that system.\n")
print("| Comparison | Metric | A [95% CI] | B [95% CI] | A - B [95% CI] | p |\n|---|---|---|---|---|---|")
docs = sorted(d for d in os.listdir(tracks) if os.path.isfile(os.path.join(tracks, d, "sentences.json")))
gold_of = {
    d: len({nt(t["sub"], t["rel"], t["obj"])
            for sentence in json.load(open(os.path.join(tracks, d, "sentences.json")))
            for t in sentence["triples"]})
    for d in docs
}
for i in range(0, len(specs), 2):
    (la, da), (lb, db) = (s.split("=", 1) for s in specs[i:i + 2])
    ca, cb = counts(da), counts(db)
    units = [(ca.get(d, (0, 0, gold_of[d])), cb.get(d, (0, 0, gold_of[d]))) for d in docs]
    for name, m in (("F1", f1), ("Precision", prec), ("Recall", rec)):
        r = paired(units, lambda u: m([x[0] for x in u]), lambda u: m([x[1] for x in u]))
        print(f"| {la} vs {lb} (n={r['n']}) | {name} | {fmt(r)} |")
