"""Score OntoLab Text2KGBench outputs with the benchmark's OFFICIAL run_eval.py, and
average the published baselines (Vicuna-13B, Alpaca-LoRA-13B) over the same sentence ids.

usage: .venv/bin/python -I t2kb_score.py <tracks/t2kb> <results/run-dir> <text2kgbench/repo> [--accepted-only]
Writes <run-dir>/official/ (sys/gt jsonl, config, per-sentence and averaged metrics) and SUMMARY.md.
"""
import json, os, subprocess, sys, glob

tracks, run, repo = sys.argv[1:4]
accepted_only = "--accepted-only" in sys.argv
tag = ("accepted" if accepted_only else "all") + ("-lenient" if "--lenient" in sys.argv else "")
off = os.path.join(run, f"official-{tag}"); os.makedirs(off, exist_ok=True)
onto_ids, ids_by_onto = [], {}
for f in sorted(glob.glob(os.path.join(run, "*.json"))):
    if f.endswith(".error.json"): continue
    r = json.load(open(f)); key = r["track"]
    sents = json.load(open(os.path.join(tracks, key, "sentences.json")))
    by = {s["id"]: [] for s in sents}
    for t in r["triples"]:
        if accepted_only and t.get("status") == "candidate": continue
        for sid in t.get("sentences") or ([t["sentence"]] if t.get("sentence") else []):
            if sid in by: by[sid].append([t["sub"], t["rel"], t["obj"]])
    with open(os.path.join(off, f"{key}_sys.jsonl"), "w") as o:
        for sid, trs in by.items(): o.write(json.dumps({"id": sid, "triples": trs}) + "\n")
    with open(os.path.join(off, f"{key}_gt.jsonl"), "w") as o:
        for s in sents: o.write(json.dumps({"id": s["id"], "sent": s["sent"], "triples": s["triples"]}) + "\n")
    os.system(f"cp '{os.path.join(tracks, key, 'ontology.json')}' '{os.path.join(off, key + '_onto.json')}'")
    onto_ids.append(key); ids_by_onto[key] = [s["id"] for s in sents]

avg = os.path.join(off, "avg.jsonl")
if os.path.exists(avg): os.remove(avg)
cfg = {"onto_list": onto_ids, "avg_out_file": avg, "path_patterns": {
    "sys": os.path.join(off, "$$onto$$_sys.jsonl"), "gt": os.path.join(off, "$$onto$$_gt.jsonl"),
    "onto": os.path.join(off, "$$onto$$_onto.json"), "output": os.path.join(off, "$$onto$$_eval.jsonl")}}
json.dump(cfg, open(os.path.join(off, "config.json"), "w"))
env = dict(os.environ, NLTK_DATA=os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", ".venv", "nltk_data"))
subprocess.run([sys.executable, "-I", os.path.join(repo, "src/evaluation/run_eval.py"), "--eval_config_path", os.path.join(off, "config.json")],
               check=True, env=env, stdout=subprocess.DEVNULL)
rows = [json.loads(l) for l in open(avg)]
glob_row = rows[-1]

M = ["avg_precision", "avg_recall", "avg_f1", "avg_onto_conf", "avg_sub_halluc", "avg_rel_halluc", "avg_obj_halluc"]
def baseline(name):
    """Average a published baseline's per-sentence metrics over exactly our sentence ids (all-test-cases convention)."""
    per = []
    for key in onto_ids:
        f = os.path.join(repo, "data", os.environ.get("T2KB_SUBSET", "dbpedia_webnlg"), "baselines", name, "eval_metrics", f"ont_{key}_eval_results.jsonl")
        if not os.path.exists(f): return None
        got = {d["id"]: d for d in map(json.loads, open(f))}
        ids = ids_by_onto[key]
        per.append({m: sum(float(got[i][m.replace("avg_", "")]) if i in got else 0.0 for i in ids) / len(ids) for m in M})
    return {m: sum(p[m] for p in per) / len(per) for m in M}

lines = [f"# Study 3 - Text2KGBench ({os.environ.get("T2KB_SUBSET", "dbpedia_webnlg")}), official metric ({tag} facts)", "",
         f"Ontologies: {len(onto_ids)} · sentences per ontology: first {len(next(iter(ids_by_onto.values())))} of the test split",
         "", "| System | P | R | F1 | Onto. conformance | Subj. halluc. | Rel. halluc. | Obj. halluc. |", "|---|---|---|---|---|---|---|---|"]
first = json.load(open(sorted(f for f in glob.glob(os.path.join(run, "*.json")) if not f.endswith(".error.json"))[0]))
lines.append(f"| OntoLab {first['provider']}/{first['model']} [{first['config']}] | " + " | ".join(f"{float(glob_row[m]):.2f}" for m in M) + " |")
for b in ["Vicuna-13B", "Alpaca-LoRA-13B"]:
    v = baseline(b)
    if v: lines.append(f"| {b} (published outputs, same sentences) | " + " | ".join(f"{v[m]:.2f}" for m in M) + " |")
import re
def nt(a, b, c): return "|".join(re.sub(r"(_|\s+|\")", "", x).lower() for x in (a, b, c))
LENIENT = "--lenient" in sys.argv
def lenient(x):
    x = re.sub(r"_?\((?:[^()]*)\)\s*$", "", x.strip())         # DBpedia disambiguation / unit suffix: Arion_(comicsCharacter), 125.8 (metres)
    x = re.sub(r"^(\d+)\.0$", r"\1", x.strip())                 # 2014.0 -> 2014
    return x
if LENIENT:
    _nt = nt
    def nt(a, b, c): return _nt(lenient(a), b, lenient(c))
tp = pr = gd = 0; per_c = []
for f in sorted(glob.glob(os.path.join(run, "*.json"))):
    if f.endswith(".error.json"): continue
    r = json.load(open(f)); sents = json.load(open(os.path.join(tracks, r["track"], "sentences.json")))
    gold = {nt(t["sub"], t["rel"], t["obj"]) for s_ in sents for t in s_["triples"]}
    pred = {nt(t["sub"], t["rel"], t["obj"]) for t in r["triples"] if not (accepted_only and t.get("status") == "candidate")}
    k = len(gold & pred); tp += k; pr += len(pred); gd += len(gold); per_c.append((r["track"], k, len(pred), len(gold)))
def corpus_row(name, tp, pr, gd):
    P = tp / pr if pr else 0; R = tp / gd if gd else 0
    return f"| {name} | {P:.3f} | {R:.3f} | {(2*P*R/(P+R) if P+R else 0):.3f} | {tp}/{pr}/{gd} |"
lines += ["", "## Corpus level (the graph OntoLab builds)", "",
          "Unique facts per ontology vs unique gold facts (quotes, underscores, spaces, case normalised); micro over ontologies.",
          "Baselines: their published per-sentence outputs on the same sentences, pooled per ontology the same way.", "",
          "| System | P | R | F1 | TP/pred/gold |", "|---|---|---|---|---|", corpus_row(f"OntoLab {first['provider']}/{first['model']} [{first['config']}]", tp, pr, gd)]
for b in ["Vicuna-13B", "Alpaca-LoRA-13B"]:
    btp = bpr = bgd = 0
    for key in onto_ids:
        f = os.path.join(repo, "data", os.environ.get("T2KB_SUBSET", "dbpedia_webnlg"), "baselines", b, "eval_metrics", f"ont_{key}_eval_results.jsonl")
        if not os.path.exists(f): break
        got = {d["id"]: d for d in map(json.loads, open(f))}
        sents = json.load(open(os.path.join(tracks, key, "sentences.json")))
        gold = {nt(t["sub"], t["rel"], t["obj"]) for s_ in sents for t in s_["triples"]}
        pred = {nt(*t[:3]) for s_ in sents for t in got.get(s_["id"], {}).get("llm_triples", []) if len(t) >= 3}
        btp += len(gold & pred); bpr += len(pred); bgd += len(gold)
    else:
        lines.append(corpus_row(f"{b} (published outputs)", btp, bpr, bgd))
lines += ["", "Per ontology (OntoLab):", "", "| Ontology | P | R | F1 | OC |", "|---|---|---|---|---|"]
for r in rows[:-1]:
    if r["type"] == "all_test_cases":
        lines.append(f"| {r['onto']} | {r['avg_precision']} | {r['avg_recall']} | {r['avg_f1']} | {r['avg_onto_conf']} |")
out = os.path.join(run, f"SUMMARY-{tag}.md"); open(out, "w").write("\n".join(lines) + "\n"); print("\n".join(lines[:9]))
