"""Model cost per document: tokens and wall-clock time, OntoLab vs the direct prompt (same model, same CLI transport).

Reads the per-document result files the runners write (`usage`, `seconds`). OntoLab's usage is the run total over
every step (summary, extraction, quote repair, assertion review, entity resolution, retries); the direct baseline is
one call per document. Input and output tokens are reported as recorded by the runners. The archived Haiku runs omit
some cache accounting, so compare Haiku on output tokens and time only. A document is included only if both systems have it with nonzero usage.

usage: python3 -I stats_cost.py "<label>=<OntoLab dir>|<direct dir>" [...]
Use "<name A> vs <name B>" as the label to customise system names.
"""
import glob, json, os, statistics as st, sys

def load(d):
    out = {}
    for f in glob.glob(os.path.join(d, "*.json")):
        b = os.path.basename(f)
        if b.endswith(".error.json") or b.startswith("SUMMARY"): continue
        r = json.load(open(f)); u = r.get("usage") or {}
        i = u.get("inputTokens", u.get("input_tokens", 0)) or 0
        o = u.get("outputTokens", u.get("output_tokens", 0)) or 0
        out[r["track"]] = (i, o, r.get("seconds") or 0.0)
    return out

print("# Model cost per document: paired runs (Text2KGBench DBpedia-WebNLG, up to 25 sentences per document)\n")
print("Mean per document (median in brackets). Ratio = first system / second system, of the means.\n")
print("| System | docs | input tokens | output tokens | total tokens | seconds | ratio total tokens | ratio seconds |")
print("|---|---|---|---|---|---|---|---|")
for spec in sys.argv[1:]:
    label, dirs = spec.split("=", 1); a_dir, b_dir = dirs.split("|")
    name_a, name_b = label.split(" vs ", 1) if " vs " in label else (f"OntoLab + {label}", f"{label} direct")
    A, B = load(a_dir), load(b_dir)
    keys = sorted(k for k in A.keys() & B.keys() if sum(A[k][:2]) > 0 and sum(B[k][:2]) > 0)
    if not keys:
        print(f"| {label} | 0 | no token usage recorded | | | | | |"); continue
    def row(X):
        cols = [[X[k][0] for k in keys], [X[k][1] for k in keys], [X[k][0] + X[k][1] for k in keys], [X[k][2] for k in keys]]
        cells = [f"{st.mean(c):,.0f} [{st.median(c):,.0f}]" for c in cols[:3]] + [f"{st.mean(cols[3]):.0f} [{st.median(cols[3]):.0f}]"]
        return cells, [st.mean(c) for c in cols]
    ca, ma = row(A); cb, mb = row(B)
    print(f"| {name_a} | {len(keys)} | " + " | ".join(ca) + f" | {ma[2] / mb[2]:.1f}x | {ma[3] / mb[3]:.1f}x |")
    print(f"| {name_b} | {len(keys)} | " + " | ".join(cb) + " | | |")
