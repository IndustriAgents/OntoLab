"""OAEI Conference, official evaluation variants on the public reference (ra1):
M1 = classes, M2 = properties, M3 = both. Computes the two official OAEI baselines
exactly as the track defines them, and OntoLab's matchers, micro-averaged over the 21 pairs.

  StringEquiv: equality of lowercased local names.
  edna:        normalised edit distance on lowercased local names; OAEI reports it at the
               threshold with the best F1, which is done here too (sweep 0.50..1.00).
  OntoLab:     candidates saved by align_eval.mts; best target per source, greedy 1:1,
               kept at score >= threshold (0.85 = the default used by the fixed harness).

usage: python3 -I oaei_official_variants.py <tracks/conference> <results/02-align-matchers> [<verified.json>] > out.md
"""
import json, os, re, sys
import rdflib
from rdflib.namespace import RDF, OWL

tracks, cand_dir = sys.argv[1], sys.argv[2]
verified_file = sys.argv[3] if len(sys.argv) > 3 else None
local = lambda u: re.split(r"[#/]", u)[-1]

def entities(path):
    g = rdflib.Graph(); g.parse(path, format="xml")
    cls = {str(s) for s in g.subjects(RDF.type, OWL.Class) if isinstance(s, rdflib.URIRef)}
    props = {str(s) for t in (OWL.ObjectProperty, OWL.DatatypeProperty) for s in g.subjects(RDF.type, t) if isinstance(s, rdflib.URIRef)}
    return cls, props

def lev(a, b):
    if a == b: return 0
    prev = list(range(len(b) + 1))
    for i, ca in enumerate(a, 1):
        cur = [i]
        for j, cb in enumerate(b, 1): cur.append(min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (ca != cb)))
        prev = cur
    return prev[-1]

def greedy(scored):
    used_s, used_t, out = set(), set(), set()
    for sc, s, t in sorted(scored, reverse=True):
        if s in used_s or t in used_t: continue
        used_s.add(s); used_t.add(t); out.add((s, t))
    return out

pairs = sorted(d for d in os.listdir(tracks) if os.path.isdir(os.path.join(tracks, d)))
data = {}
for p in pairs:
    d = os.path.join(tracks, p)
    sc, sp = entities(os.path.join(d, "source.owl")); tc, tp = entities(os.path.join(d, "target.owl"))
    ref = []
    for m in re.finditer(r"<Cell\b[^>]*>([\s\S]*?)</Cell>", open(os.path.join(d, "reference.rdf")).read()):
        b = m.group(1)
        e1 = re.search(r"entity1[^>]*rdf:resource=['\"]([^'\"]+)", b).group(1); e2 = re.search(r"entity2[^>]*rdf:resource=['\"]([^'\"]+)", b).group(1)
        ref.append((e1, e2))
    data[p] = dict(sc=sc, sp=sp, tc=tc, tp=tp, ref=set(ref))

def variant_filter(v, p):
    D = data[p]
    if v == "M1": return lambda s, t: s in D["sc"] and t in D["tc"]
    if v == "M2": return lambda s, t: s in D["sp"] and t in D["tp"]
    return lambda s, t: True

def evaluate(predict, v):
    tp = pr = gd = 0
    for p in pairs:
        keep = variant_filter(v, p); ref = {x for x in data[p]["ref"] if keep(*x)}
        pred = {x for x in predict(p) if keep(*x)}
        tp += len(pred & ref); pr += len(pred); gd += len(ref)
    P = tp / pr if pr else 0; R = tp / gd if gd else 0
    return P, R, (2 * P * R / (P + R) if P + R else 0), (tp, pr, gd)

def string_equiv(p):
    D = data[p]; out = set()
    for S, T in ((D["sc"], D["tc"]), (D["sp"], D["tp"])):
        idx = {}
        for t in T: idx.setdefault(local(t).lower(), t)
        out |= {(s, idx[local(s).lower()]) for s in S if local(s).lower() in idx}
    return out

edna_cache = {}
def edna_scores(p):
    if p not in edna_cache:
        D = data[p]; sc = []
        for S, T in ((D["sc"], D["tc"]), (D["sp"], D["tp"])):
            for s in S:
                a = local(s).lower()
                for t in T:
                    b = local(t).lower(); sim = 1 - lev(a, b) / max(len(a), len(b), 1)
                    if sim >= 0.5: sc.append((sim, s, t))
        edna_cache[p] = sc
    return edna_cache[p]

def edna(th): return lambda p: greedy([x for x in edna_scores(p) if x[0] >= th])

cands = {}
for name in ("lexical", "semantic", "lss"):
    f = os.path.join(cand_dir, f"{name}.json")
    if os.path.exists(f): cands[name] = {r["track"]: r["candidates"] for r in json.load(open(f))}
def ontolab(name, th): return lambda p: greedy([(c["score"], c["source"], c["target"]) for c in cands[name].get(p, []) if c["score"] >= th])
verified = {r["track"]: r["candidates"] for r in json.load(open(verified_file))} if verified_file and os.path.exists(verified_file) else None
def ontolab_verified(p): return greedy([(c["score"], c["source"], c["target"]) for c in (verified or {}).get(p, []) if c["relation"] == "equivalent"])

rows = [("StringEquiv (official baseline)", string_equiv)]
best_edna = max((evaluate(edna(th / 100), "M3")[2], th / 100) for th in range(50, 101, 2))
rows.append((f"edna (official baseline, best threshold {best_edna[1]:.2f})", edna(best_edna[1])))
for name in cands:
    for th in (0.75, 0.85, 0.95): rows.append((f"OntoLab {name} @ {th}", ontolab(name, th)))
if verified: rows.append(("OntoLab lss + Gemini verification", ontolab_verified))

print("# OAEI Conference: official variants on the public reference ra1\n")
print("Micro-averaged over 21 pairs. M1 classes, M2 properties, M3 both (OAEI's main variant uses M3).\n")
for v in ("M3", "M1", "M2"):
    print(f"## ra1-{v}\n\n| Matcher | P | R | F1 | TP/pred/gold |\n|---|---|---|---|---|")
    for label, fn in rows:
        P, R, F, n = evaluate(fn, v); print(f"| {label} | {P:.3f} | {R:.3f} | {F:.3f} | {n[0]}/{n[1]}/{n[2]} |")
    print()

# Candidate recall: share of reference pairs that reach the candidate list at all
# (the ceiling for model verification, which only sees candidates), and list size.
print("## Candidate recall (ceiling for verification), ra1-M3\n\n| Candidates from | Recall | Candidates per pair |\n|---|---|---|")
for name in cands:
    hit = gold = n = 0
    for p in pairs:
        cs = {(c["source"], c["target"]) for c in cands[name].get(p, [])}
        hit += len(cs & data[p]["ref"]); gold += len(data[p]["ref"]); n += len(cs)
    print(f"| {name} | {hit / gold:.3f} | {n / len(pairs):.0f} |")
