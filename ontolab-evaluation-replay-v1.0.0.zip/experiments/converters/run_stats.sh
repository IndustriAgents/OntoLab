#!/usr/bin/env bash
# Rebuild the paper's main tables from frozen outputs without vendor credentials.
set -euo pipefail
CONVERTERS="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PYTHON_BIN="${ONTOLAB_STATS_PYTHON:-python3}"
if [[ -z "${ONTOLAB_STATS_PYTHON:-}" && -x "$CONVERTERS/../.venv/bin/python" ]]; then
  PYTHON_BIN="$CONVERTERS/../.venv/bin/python"
fi
exec "$PYTHON_BIN" -I "$CONVERTERS/replay.py" "$@"
