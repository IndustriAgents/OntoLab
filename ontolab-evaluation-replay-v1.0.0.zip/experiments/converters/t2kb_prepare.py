"""Text2KGBench -> OntoLab inputs.

For each DBpedia-WebNLG ontology writes tracks/t2kb/<onto>/:
  tbox.ttl      OWL T-Box from the JSON ontology. Relations whose range is a literal
                (number/string/Date/Year/'') become owl:DatatypeProperty; others
                owl:ObjectProperty. Local names = the benchmark's relation labels, so
                predictions can be scored with the benchmark's string metric.
  doc.txt       the first N test sentences, one per paragraph (blank line between)
  sentences.json  [{id, sent, start, end, triples}] with character offsets into doc.txt

usage: python3 -I t2kb_prepare.py <text2kgbench/repo/data> <out-dir> <N> [onto,onto,...]
"""
import json, os, re, sys

LITERAL = {"number": "decimal", "string": "string", "Date": "date", "date": "date", "Year": "gYear", "": "string"}

def safe(s):
    return re.sub(r"[^A-Za-z0-9_]", "_", s) or "x"

def tbox(o, base):
    cls = {c["qid"]: c["label"] for c in o["concepts"]}
    lines = ["@prefix owl: <http://www.w3.org/2002/07/owl#> .", "@prefix rdfs: <http://www.w3.org/2000/01/rdf-schema#> .",
             "@prefix xsd: <http://www.w3.org/2001/XMLSchema#> .", f"@prefix : <{base}#> .", "",
             f"<{base}> a owl:Ontology ; rdfs:label \"{o['title']}\" .", ""]
    extra = set()
    for r in o["relations"]:
        for k in ("domain", "range"):
            v = r[k]
            if v and v not in cls and not (k == "range" and v in LITERAL): extra.add(v)
    for q, label in list(cls.items()) + [(e, e) for e in sorted(extra)]:
        lines.append(f":{safe(q)} a owl:Class ; rdfs:label \"{label}\" .")
    for r in o["relations"]:
        name = safe(r["label"].replace(" ", "_"))
        dom = f" ; rdfs:domain :{safe(r['domain'])}" if r["domain"] else ""
        if r["range"] in LITERAL:
            lines.append(f":{name} a owl:DatatypeProperty ; rdfs:label \"{r['label']}\"{dom} ; rdfs:range xsd:{LITERAL[r['range']]} .")
        else:
            lines.append(f":{name} a owl:ObjectProperty ; rdfs:label \"{r['label']}\"{dom} ; rdfs:range :{safe(r['range'])} .")
    return "\n".join(lines) + "\n"

def main(data, out, n, only):
    ddir = os.path.join(data, os.environ.get("T2KB_SUBSET", "dbpedia_webnlg"))  # wikidata_tekgen for the held-out half
    for f in sorted(os.listdir(os.path.join(ddir, "ontologies"))):
        if not f.endswith(".json"): continue
        o = json.load(open(os.path.join(ddir, "ontologies", f)))
        key = f.replace("_ontology.json", "")
        if only and key not in only: continue
        sel = os.environ.get("T2KB_SELECT", "")  # TekGen: "verified" = manually validated test cases; "unseen" = author-written, not in Wikipedia
        if sel == "unseen":
            gpath = os.path.join(ddir, "unseen_sentences", "ground_truth", f"ont_{key}_unseen_ground_truth.jsonl")
            if not os.path.exists(gpath): continue
            gt = [json.loads(l) for l in open(gpath) if l.strip()][:n]
        else:
            gt = [json.loads(l) for l in open(os.path.join(ddir, "ground_truth", f"ont_{key}_ground_truth.jsonl"))]
            if sel == "verified":
                keep = {l.strip() for l in open(os.path.join(ddir, "manually_verified_sentences", f"selected_ont_{key}.txt")) if l.strip()}
                gt = [g for g in gt if g["id"] in keep]
            gt = gt[:n]
        d = os.path.join(out, key); os.makedirs(d, exist_ok=True)
        text, sents = "", []
        for g in gt:
            if text: text += "\n\n"
            start = len(text); text += g["sent"]
            sents.append({"id": g["id"], "sent": g["sent"], "start": start, "end": len(text), "triples": g["triples"]})
        open(os.path.join(d, "doc.txt"), "w").write(text + "\n")
        json.dump(sents, open(os.path.join(d, "sentences.json"), "w"), indent=1)
        json.dump(o, open(os.path.join(d, "ontology.json"), "w"))
        open(os.path.join(d, "tbox.ttl"), "w").write(tbox(o, f"https://w3id.org/t2kb/{key}"))
        print(key, len(sents), "sentences", sum(len(s["triples"]) for s in sents), "gold triples")

main(sys.argv[1], sys.argv[2], int(sys.argv[3]), set(sys.argv[4].split(",")) if len(sys.argv) > 4 else None)
