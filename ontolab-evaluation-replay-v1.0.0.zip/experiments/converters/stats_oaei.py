"""OAEI Conference (ra1-M3): paired bootstrap over the 21 ontology pairs, micro-averaged F1, P, R.
Reuses oaei_official_variants.py's own data loading and matchers (run in-process), so the point
estimates are exactly the reported ones.
usage: python3 -I stats_oaei.py <tracks/conference> <results/02-align-matchers> "<label>=<verified.json>" [...]
"""
import contextlib, io, json, os, runpy, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from stats_common import paired, fmt
tracks, cand, *verified = sys.argv[1:]
here = os.path.dirname(os.path.abspath(__file__))
def load_module(vfile):
    argv = sys.argv; sys.argv = ["x", tracks, cand, vfile]
    with contextlib.redirect_stdout(io.StringIO()): g = runpy.run_path(os.path.join(here, "oaei_official_variants.py"))
    sys.argv = argv; return g
systems = {}
g = None
for spec in verified:
    label, vfile = spec.split("=", 1)
    if not os.path.exists(vfile): sys.exit(f"missing {vfile}")
    g = load_module(vfile)
    systems[label] = {p: g["ontolab_verified"](p) for p in g["pairs"]}
systems["edna (official baseline)"] = {p: g["edna"](g["best_edna"][1])(p) for p in g["pairs"]}
systems["StringEquiv (official baseline)"] = {p: g["string_equiv"](p) for p in g["pairs"]}
refs = {p: g["data"][p]["ref"] for p in g["pairs"]}
def per_pair(sysname): return [(len(systems[sysname][p] & refs[p]), len(systems[sysname][p]), len(refs[p])) for p in g["pairs"]]
def f1(cs):
    tp, pr, gd = (sum(c[i] for c in cs) for i in range(3)); P = tp / pr if pr else 0; R = tp / gd if gd else 0
    return 2 * P * R / (P + R) if P + R else 0
print("# OAEI Conference ra1-M3: paired bootstrap over the 21 ontology pairs (10,000 resamples)\n")
print("| Comparison | F1 A [95% CI] | F1 B [95% CI] | A - B [95% CI] | p |\n|---|---|---|---|---|")
names = list(systems)
import re as _re
rep = lambda n: _re.search(r" r\d+$", n) is not None  # repeat runs: compared with the baselines only
main = [n for n in names[:len(verified)] if not rep(n)]
comparisons = [(a, b) for a in names[:len(verified)] for b in names[len(verified):]] + [(main[i], main[j]) for i in range(len(main)) for j in range(i + 1, len(main))]
for a, b in comparisons:
    pa, pb = per_pair(a), per_pair(b); units = list(zip(pa, pb))
    r = paired(units, lambda u: f1([x[0] for x in u]), lambda u: f1([x[1] for x in u]))
    print(f"| {a} vs {b} | {fmt(r)} |")

groups = {}
for n in names[:len(verified)]: groups.setdefault(_re.sub(r" r\d+$", "", n), []).append(f1(per_pair(n)))
if any(len(v) > 1 for v in groups.values()):
    import statistics
    print("\n## Run-to-run variance (verification repeats)\n\n| System | runs | F1 per run | mean (sd) |\n|---|---|---|---|")
    for k, v in groups.items():
        if len(v) > 1: print(f"| {k} | {len(v)} | {' / '.join(f'{x:.3f}' for x in v)} | {statistics.mean(v):.3f} ({statistics.stdev(v):.3f}) |")
