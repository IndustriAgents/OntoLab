"""Audit sentence coverage, vocabulary use, and full-date sensitivity on frozen outputs."""
import json
import re
from datetime import datetime
from pathlib import Path
from statistics import mean

RESULTS = Path(__file__).resolve().parents[1] / "results"
MONTH_DATE = re.compile(r"\b(?:\d{1,2} [a-z]+ \d{4}|[a-z]+ \d{1,2},? \d{4})\b", re.I)
DATE_FORMATS = ("%d %B %Y", "%d %b %Y", "%B %d, %Y", "%b %d, %Y", "%B %d %Y", "%b %d %Y")


def read_rows(path):
    return [json.loads(line) for line in path.read_text().splitlines() if line.strip()]


def normalize(value, lenient=False):
    if lenient:
        value = re.sub(r"_?\([^()]*\)\s*$", "", value.strip()).strip()
        value = re.sub(r"^(\d+)\.0$", r"\1", value)
    return re.sub(r'[_\s"]', "", value).lower()


def canonical_date(value):
    date = value.strip().strip('"').replace("_", " ")
    if MONTH_DATE.fullmatch(date):
        for fmt in DATE_FORMATS:
            try:
                return datetime.strptime(date, fmt).date().isoformat()
            except ValueError:
                continue
    return value


def triple_key(triple, *, lenient=False, dates=False):
    obj = canonical_date(triple["obj"]) if dates else triple["obj"]
    return normalize(triple["sub"], lenient), normalize(triple["rel"]), normalize(obj, lenient)


def date_f1(run, dates):
    totals = [0, 0, 0]
    for path in sorted(run.glob("[0-9]*.json")):
        if path.name.endswith(".error.json"):
            continue
        output = json.loads(path.read_text())
        gold_path = sorted(run.glob(f'official-*/{output["track"]}_gt.jsonl'))[0]
        gold = {triple_key(t, lenient=True, dates=dates) for row in read_rows(gold_path) for t in row["triples"]}
        predicted = {triple_key(t, lenient=True, dates=dates) for t in output["triples"]}
        totals[0] += len(gold & predicted)
        totals[1] += len(predicted)
        totals[2] += len(gold)
    return 2 * totals[0] / (totals[1] + totals[2])


def audit_sentence_coverage(run):
    exact = attributed = multiple = covered = sentences = 0
    per_sentence_f1 = []
    for gt_path in sorted((run / "official-all").glob("*_gt.jsonl")):
        topic = gt_path.name.removesuffix("_gt.jsonl")
        output = json.loads((run / f"{topic}.json").read_text())
        gold_sources = {}
        gold = read_rows(gt_path)
        predictions = {}
        for row in gold:
            for triple in row["triples"]:
                gold_sources.setdefault(triple_key(triple), set()).add(row["id"])
        for triple in output["triples"]:
            predictions.setdefault(triple_key(triple), set()).update(triple["sentences"])
        for triple in predictions.keys() & gold_sources.keys():
            exact += 1
            attributed += bool(predictions[triple] & gold_sources[triple])
            multiple += len(predictions[triple]) > 1
        official = read_rows(run / "official-all" / f"{topic}_eval.jsonl")
        covered += sum(bool(row["llm_triples"]) for row in official)
        sentences += len(official)
        per_sentence_f1.extend(float(row["f1"]) for row in official)
    return sentences, covered, exact, attributed, multiple, mean(per_sentence_f1)


def main():
    print("# Extraction diagnostics")
    print("\n## Haiku sentence attribution")
    print("\nStrict here retains the benchmark harness's case, underscore, quote and whitespace normalisation.")
    print("\n| Run | Sentences | Sentences with predictions | Unique matched triples | Match attributed to a gold sentence | Matches with multiple predicted IDs | Mean per-sentence F1 |")
    print("|---|---:|---:|---:|---:|---:|---:|")
    for name, relative in (("OntoLab", "23-haiku/t2kb-ontolab-v4"), ("Direct", "23-haiku/t2kb-direct")):
        sentences, covered, exact, attributed, multiple, f1 = audit_sentence_coverage(RESULTS / relative)
        print(f"| {name} | {sentences} | {covered} | {exact} | {attributed} | {multiple} | {f1:.3f} |")

    print("\n## TekGen sensitivity to full-date formatting")
    print("\nThe same rules apply to reference and predicted object values. Year-only and ambiguous numeric dates retain their original precision.")
    print("\n| Model | Subset | Run | Main F1 | With date normalisation |")
    print("|---|---|---|---:|---:|")
    for model, folder in (("Haiku", "34-haiku"), ("Luna", "35-luna")):
        for subset in ("verified", "unseen"):
            for system in ("ontolab", "direct"):
                run = RESULTS / folder / f"tekgen-{subset}-{system}"
                print(f"| {model} | {subset} | {system} | {date_f1(run, False):.3f} | {date_f1(run, True):.3f} |")


if __name__ == "__main__":
    main()
