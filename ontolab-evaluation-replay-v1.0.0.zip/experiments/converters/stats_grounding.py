"""Resample topics while preserving paired original/corrupted facts and both scores."""
import json
import os
import sys
from collections import defaultdict
from pathlib import Path

import numpy as np
from scipy.stats import rankdata

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from stats_common import fmt, paired


def auroc(positive, negative):
    ranks = rankdata(np.concatenate([positive, negative]))
    n_positive, n_negative = len(positive), len(negative)
    return (ranks[:n_positive].sum() - n_positive * (n_positive + 1) / 2) / (n_positive * n_negative)


def caught5(positive, negative):
    return float((negative < np.percentile(positive, 5)).mean())


def comparison(directory, model, corruption):
    groups = defaultdict(list)
    keys = ("origCited", "swapCited", "origAny", "swapAny")
    path = directory / f"inject-{corruption}-{model}-ontolab.jsonl"
    for line in path.read_text().splitlines():
        if line.strip():
            row = json.loads(line)
            groups[row["track"]].append([row[key] for key in keys])
    topics = [np.array(group) for group in groups.values()]

    def score(units, metric, offset):
        values = np.concatenate(units)
        return metric(values[:, offset], values[:, offset + 1])

    n = sum(map(len, topics))
    for name, metric in (("AUROC", auroc), ("caught @5% FA", caught5)):
        yield name, n, len(topics), paired(
            topics, lambda units: score(units, metric, 0), lambda units: score(units, metric, 2)
        )


def main():
    directory = Path(sys.argv[1])
    print("# Grounding injection: paired bootstrap over topics (10,000 resamples)")
    print()
    print("All original/corrupted pairs in a sampled topic travel together. The 5th percentile is recalculated for each check and draw.")
    print()
    print("| Facts from | Corruption | Metric | Own citation [95% CI] | Anywhere [95% CI] | Difference [95% CI] | p |")
    print("|---|---|---|---|---|---|---|")
    for model in ("gemini", "haiku"):
        for corruption in ("object", "subject", "relation", "number"):
            for name, n, topics, result in comparison(directory, model, corruption):
                print(f"| {model.capitalize()} | {corruption} (n={n}, topics={topics}) | {name} | {fmt(result)} |")


if __name__ == "__main__":
    main()
