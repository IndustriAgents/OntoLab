"""Run-to-run variance on Text2KGBench: whole-graph lenient F1 (same matching as stats_t2kb.py) per run, mean and sd.
usage: python3 -I stats_repeats.py <tracks/t2kb> "<system>=<run dir>,<run dir>,..." [...]
"""
import glob, json, os, re, statistics, sys
tracks, *specs = sys.argv[1:]
def nt(a, b, c):
    L = lambda x: re.sub(r"^(\d+)\.0$", r"\1", re.sub(r"_?\((?:[^()]*)\)\s*$", "", x.strip()).strip())
    return "|".join(re.sub(r"(_|\s+|\")", "", x).lower() for x in (L(a), b, L(c)))
def prf(run):
    tp = pr = gd = 0
    for f in glob.glob(os.path.join(run, "*.json")):
        if f.endswith(".error.json") or os.path.basename(f).startswith("SUMMARY"): continue
        r = json.load(open(f))
        if "track" not in r: continue
        gold = {nt(t["sub"], t["rel"], t["obj"]) for s in json.load(open(os.path.join(tracks, r["track"], "sentences.json"))) for t in s["triples"]}
        pred = {nt(t["sub"], t["rel"], t["obj"]) for t in r["triples"]}
        tp += len(pred & gold); pr += len(pred); gd += len(gold)
    P = tp / pr if pr else 0; R = tp / gd if gd else 0
    return P, R, (2 * P * R / (P + R) if P + R else 0)
print("# Text2KGBench DBpedia-WebNLG: run-to-run variance (whole-graph, lenient)\n")
print("| System | runs | F1 per run | F1 mean (sd) | P mean | R mean |\n|---|---|---|---|---|---|")
for spec in specs:
    label, dirs = spec.split("=", 1)
    runs = [d for d in dirs.split(",") if os.path.isdir(d)]
    if not runs: continue
    v = [prf(d) for d in runs]; F = [x[2] for x in v]
    sd = statistics.stdev(F) if len(F) > 1 else float("nan")
    print(f"| {label} | {len(F)} | {' / '.join(f'{x:.3f}' for x in F)} | {statistics.mean(F):.3f} ({sd:.3f}) | {statistics.mean(x[0] for x in v):.3f} | {statistics.mean(x[1] for x in v):.3f} |")
