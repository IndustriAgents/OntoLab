"""OLLM arXiv benchmark: fixed document sample + page-free gold graphs.
Every non-root concept contributes k papers (seeded; a paper attached to several concepts is used once),
so each gold concept is represented. Writes <out>/<split>/{docs.jsonl, gold.json}.

usage: python3 -I ollm_sample.py <datasets/ollm/arxiv> <tracks/ollm> [k=5] [seed=13]
"""
import json, os, random, sys
src, out = sys.argv[1], sys.argv[2]
k = int(sys.argv[3]) if len(sys.argv) > 3 else 5
seed = int(sys.argv[4]) if len(sys.argv) > 4 else 13
for split, name in (("train_test_split", "test"), ("train_eval_split", "eval")):
    g = json.load(open(os.path.join(src, split, "test_graph.json")))
    rnd = random.Random(seed); used, docs = set(), []
    for n in sorted(g["nodes"], key=lambda n: str(n["id"])):
        if n["id"] == g["graph"]["root"]: continue
        pages = sorted((p for p in n.get("pages", []) if p["id"] not in used), key=lambda p: str(p["id"]))
        for p in rnd.sample(pages, min(k, len(pages))):
            used.add(p["id"]); docs.append({"id": str(p["id"]), "title": p["title"], "abstract": p["abstract"], "sampledFor": n["title"]})
    for n in g["nodes"]: n.pop("pages", None)
    os.makedirs(os.path.join(out, name), exist_ok=True)
    json.dump(g, open(os.path.join(out, name, "gold.json"), "w"))
    with open(os.path.join(out, name, "docs.jsonl"), "w") as f:
        for d in docs: f.write(json.dumps(d) + "\n")
    print(name, "concepts", len(g["nodes"]), "edges", len(g["links"]), "docs", len(docs), "chars", sum(len(d["abstract"]) for d in docs))
