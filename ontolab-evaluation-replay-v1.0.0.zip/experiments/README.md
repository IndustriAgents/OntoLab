# Experiments: OntoLab on public benchmarks

Start with `RESULTS.md` (current numbers) and `DESIGN.md` (what each study measures, dated amendments).

## Layout

| Path | What |
|---|---|
| `RESULTS.md` | Consolidated results with CIs; what holds and what does not |
| `DESIGN.md` | Studies, metrics, statistics, amendments log |
| `ONTOLAB_VERSION.md` | Which OntoLab code each run used (pinned commits + `patches/`) |
| `PROTECTED-DATA.md` | **Read before committing anything.** CQ benchmark data stays local |
| `setup.sh` | Recreates `.venv/`, `datasets/`, `tracks/`, the OntoLab copies and the model cache |
| `converters/` | Dataset converters, runners (`*.mts`), scorers, statistics (`stats_*.py`, `run_stats.sh`), run queues (`run_queueN.sh`) |
| `grids/` | Configuration grids (`study3-kg.json`: extraction configurations incl. the ablations) |
| `results/NN-*/` | Raw outputs, per-run scores and `SUMMARY*.md`, numbered in run order. `28-stats-*.md` = statistics tables |
| `logs/` | Queue logs (timings, triple counts, failures). Grep for `unavailable` / `fallback` before trusting a run |
| `docs/` | Side documents (e.g. the Text2KGBench-LettrIA access request draft) |
| `sync_from_workdir.sh` | Copies new results from the author's work directory (`ONTOLAB_WORKDIR`) into this repo, with the protected-data filters |

## Result index

| Dir | Study | Notes |
|---|---|---|
| 00, 03 | mock-provider smoke tests | no model |
| 01, 02, 02b, 09, 15, 18, 19 | OAEI Conference / MSE alignment: model-free matchers, embedders, relative thresholds, hybrid | |
| 08 | OAEI with Gemini verification | headline alignment run |
| 04, 06, 10, 11, 12 | Text2KGBench pilots, configuration grid, prompt v2, repeat, Flash medium | grid-06 tree-prompt and edc-retrieval configs invalid (model fallback) |
| 07 | Text2KGBench direct-prompt baseline (Gemini) | |
| 05, 14, 16 | ContractNLI evidence gate; NLI model size | |
| 17 | Text2KGBench, OntoLab v3 (Gemini) | headline extraction run |
| 20 | OLLM arXiv taxonomy induction (Gemini) | `*-HASHFALLBACK-invalid` set aside |
| 21 | CQ-driven ontology generation (Lippolis) | **only SUMMARY tables in git** |
| 22 | gpt-oss-120b | abandoned (agy quota) |
| 23 | Claude Haiku: Text2KGBench v3/v4, OAEI, OLLM, CQ | |
| 24 | Text2KGBench v4 (Gemini, clean rerun) | `*-FALLBACK-invalid` set aside |
| 27 | grounding study (citation-anchored NLI vs best sentence; error injection) | |
| 28 | statistics tables (`converters/run_stats.sh`), incl. `28-stats-heldout-ablation-repeats.md` | |
| 30-luna, 35-luna | GPT-6 Luna (codex CLI, medium, code with PR #45): main benchmarks; held-out + ablations + repeats + OAEI repeats | CQ ontologies of Luna stay local (protected) |
| 34-haiku | Haiku: held-out TekGen (verified, unseen), 3 ablations, 2 extra repeats, OAEI repeats | |
| `*-INVALID-*`, `*FALLBACK-invalid` | kept for the record, never scored | |
| `34-haiku/_failed-logs/` | logs of OAEI runs stopped by the misclassified network error (PR #46) | |

## Prepare to regenerate predictions

    experiments/setup.sh            # once
    # sign in to the CLIs you use: agy, claude, codex
    export PATH=$HOME/.nvm/versions/node/v22.23.5/bin:$PATH LOCAL_CLI_ENABLED=1 EMBEDDINGS_BACKEND=local NLI_BACKEND=local
    bash converters/run_stats.sh    # replay from frozen results, see below

The run queues (`converters/run_queueN.sh`, `run_heldout_ablation_parts.sh`, `retry_failed_topics.sh`) show the exact
command for every result directory. They contain the absolute path of the original work directory; `setup.sh` prints
the `sed` line that rewrites it.

## Replay the paper

Use Python 3.11 or 3.12 with the small analysis environment. Model services are unnecessary for replay.

    cd experiments
    python3 -m venv .venv
    .venv/bin/python -m pip install -r replay-requirements.txt
    bash converters/run_stats.sh
    .venv/bin/python ../paper/figures/make_figures.py

The command writes rebuilt tables to build/replay/. It recomputes graph, alignment and grounding statistics
from saved outputs and public references. It reads sentence and taxonomy scores from archived official
evaluator outputs. For alignment, it downloads the checksum-verified public Conference archives using
curl. Pass --conference /path/to/tracks/conference to use a local copy, or --offline to omit alignment.
Choose another output folder with --output PATH. Pass ONTOLAB_STATS_PYTHON to select a different Python.

The [worked review](examples/vessel-review/) includes a synthetic note, an ontology, a draft, a decision log
and expected Turtle. The [human validation plan](docs/HUMAN-STUDY.md) and [annotation sheet](docs/human-review-template.csv)
prepare the independent review. [Competency-question aggregates](docs/CQ-SUPPLEMENT.md) are exploratory.

## Repeat the two-pass extraction baseline

With the CLI on PATH and signed in and the model-inference setup above complete, execute this
from the experiment directory. Change the output directory to retain multiple runs.

    LOCAL_CLI_ENABLED=1 ontolab-v4/node_modules/.bin/tsx \
      converters/t2kb_document_review.mts "$PWD" tracks/t2kb \
      results/document-review-haiku claude-cli haiku

The runner also accepts one topic ID as the last argument. The frozen comparison in the paper was scored
on all 19 topics. See the [comparison table](results/36-stats-document-review.md).

## Prepare a reviewer archive

Run python3 converters/package_replay.py from the experiment directory after rebuilding the paper.
This creates build/ontolab-evaluation-replay.zip with the manuscript, replay code, the inputs it
reads, and a SHA-256 manifest. It omits protected data, raw CQ ratings, inference logs, and discarded
model runs. Confirm the license and attribution requirements for redistributed benchmark snapshots
before public release.
