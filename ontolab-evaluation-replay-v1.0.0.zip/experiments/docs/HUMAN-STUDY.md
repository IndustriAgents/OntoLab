# Independent evaluation of source-grounded review

Status — protocol to freeze before collecting ratings. The manuscript reports the synthetic comparison and automatic diagnostics. Human estimates require independent ratings.

## Materials

- Select 8–12 real documents with multiple paragraphs, reused property values, and source text that can be shared with reviewers. Record the source URL, version, date, redistribution terms, character offsets and target OWL ontology. Include at least two domains and freeze document selection before any extraction.
- Use two documents for training and threshold calibration. Hold the remaining documents out for evaluation.
- Run a pinned OntoLab configuration in flag mode. Export all proposals with exact citations and scores, including unlocated or missing spans. On the same proposals, compute the maximum post-hoc score over candidate passages using the identical verbalization, NLI model and context-window rule. Store the two premise texts and score outputs separately from the annotation sheet.
- Sample about 150–250 unique assertions from the test documents with a fixed seed. Use a uniform random sample for prevalence. If a separate disagreement sample is needed to obtain enough errors, report it separately with its own denominator. Keep the natural error set distinct from the synthetic experiment.
- Give each rater a private copy of the CSV. Add the observable columns for each item and leave decision fields blank. Preserve the random order and use the local document reference in place of the document text where redistribution is restricted.

## Assessment

Two independent raters first label each assertion against the document. They then judge whether the displayed passage supports the specific subject, property and object. Use one label from **supported**, **contradicted**, **insufficient**, or **unassessable** for each question. Select an error type when applicable from **wrong subject**, **wrong property**, **wrong object**, **wrong number or unit**, **unsupported or ambiguous**, or **schema mapping**. Record the supporting or contradicting offsets and distinguish a located-but-irrelevant citation from an unlocated citation.

For review effort, randomize which presentation a reviewer sees first. Compare the original citation view with the strongest post-hoc passage view on the same sampled assertions, giving each rater only one presentation per assertion and balancing presentation across raters and documents. Use anonymized method labels. Time from showing the assertion to submitting its passage-support decision. Have both raters judge overall document support before adjudication. Report each timed condition's accuracy as well as its duration.

## Analysis and reporting

- Fix production thresholds using the training documents. Report false-alarm and detection rates on held-out documents with document-clustered intervals. Report missing-citation and unassessable rates alongside the denominators.
- Report agreement before adjudication, using raw agreement and Cohen’s kappa. Resolve disagreements with documented reasons, then report detection on adjudicated labels. Preserve unassessable labels.
- Report natural wrong-object counts, passage-support precision and coverage, detection for each comparison, and review time with decision accuracy. Use a paired document-level analysis when both conditions occur within each document.
- Keep the frozen protocol, manifest, anonymized ratings or aggregate tables, and adjudication notes. Leave restricted documents and protected competency-question materials out of the release.

Companion checklist — [annotation sheet](human-review-template.csv).
