# Results

The [revision results](#manuscript-revision-and-new-comparison-2026-11-21) supersede the claims and
intervals in the original run notes below. The frozen measurements are retained for provenance.

## Original runs through 2026-11-21, 14:15 CET

Statistics: paired bootstrap over benchmark units, 10,000 resamples, seed 20261120, 95% CI on the difference,
two-sided p. Rebuild every table with `converters/run_stats.sh` → `results/28-stats-*.md`. "Direct" = the same model
asked to extract the triples with one prompt (no OntoLab). Three model vendors: Gemini 3.8 Flash low (Google, via agy),
Claude Haiku (Anthropic, claude CLI), GPT-6 Luna medium (OpenAI, codex CLI). All runs were checked for silent
embedder/NLI fallbacks (none in the runs below).

## 1. Extraction: Text2KGBench DBpedia-WebNLG (19 topics, whole-graph lenient F1)

Tables: `28-stats-t2kb.md`, `28-stats-heldout-ablation-repeats.md`.

| Model | OntoLab | Direct | Δ [95% CI] (run 1) | p |
|---|---|---|---|---|
| Gemini 3.8 Flash low (v3; v4 rerun identical) | 0.641 | 0.489 | +0.15 [+0.09, +0.22] | <0.001 |
| Claude Haiku (v4) | 0.561 | 0.500 | +0.06 [+0.01, +0.12] | 0.03 |
| GPT-6 Luna medium (v4) | 0.594 | 0.505 | +0.09 [+0.04, +0.14] | <0.001 |

The gain comes from **precision**: +0.27 Gemini, +0.17 Haiku, +0.14 to +0.22 Luna, p≤0.001 in every run. Recall is
not better than direct (Haiku −0.03, Luna −0.03 to −0.06, n.s.). Proposed-facts fix (Haiku v3 → v4, PR #44): +0.12 [+0.05, +0.20].

**Run-to-run variance (3 runs each):**

| System | F1 per run | mean (sd) |
|---|---|---|
| OntoLab + Haiku | 0.561 / 0.487 / 0.569 | 0.539 (0.045) |
| Haiku direct | 0.500 / 0.488 / 0.480 | 0.490 (0.010) |
| OntoLab + Luna | 0.594 / 0.569 / 0.533 | 0.565 (0.031) |
| Luna direct | 0.505 / 0.490 / 0.498 | 0.498 (0.008) |

Δ per run: Haiku +0.06 / −0.00 / +0.09 (2 of 3 significant), Luna +0.09 / +0.08 / +0.04 (2 of 3 significant).
OntoLab varies 3–4× more between runs than the direct prompt; report the F1 gain as a mean over runs. Gemini: two
runs gave identical F1.

**Ablations (vs the full configuration of run 1):**

| Configuration | Haiku F1 | Δ full − abl. (p) | Luna F1 | Δ full − abl. (p) |
|---|---|---|---|---|
| full (retrieval + evidence gate) | 0.561 | | 0.594 | |
| no retrieval, no evidence gate (full T-Box) | 0.531 | +0.03 (0.03) | 0.561 | +0.03 (0.07) |
| retrieval, no evidence gate (EDC-style) | 0.540 | +0.02 (0.13) | 0.597 | −0.00 (0.87) |
| evidence gate in auto-accept mode | 0.511 | +0.05 (0.12) | 0.546 | +0.05 (0.06) |

No component is individually significant; effects are within run-to-run spread. The evidence gate adds no F1 with
Luna. Even the simplest ablation beats the direct prompt (0.53/0.56 vs ≈0.50; not a paired test): most of the gain
comes from **schema-constrained extraction into the target ontology**, not from retrieval or the gate.
(Tree-prompt configuration: grid 06 invalid, not rerun.)

**Cost per document (`28-stats-cost.md`; same model and CLI; OntoLab counts every step and retry):**

| Model | total tokens OntoLab / direct | ratio | median seconds OntoLab / direct |
|---|---|---|---|
| Gemini | 24,894 / 4,314 | 5.8× | 72 / 18 |
| Luna | 73,804 / 12,572 | 5.9× | 111 / 41 |
| Luna, retrieval without evidence | 53,129 / 12,572 | 4.2× | 102 / 41 |
| Haiku (output tokens only) | 13,656 / 7,157 | 1.9× | 56 / 26 |

The evidence step costs about +20k tokens per document with Luna (+39%) and adds no F1. Haiku input tokens are
under-reported for both systems: OntoLab did not count Claude prompt-cache writes (fixed in PR #47), so Haiku is
compared on output tokens and time only.

## 2. Held-out extraction: Text2KGBench Wikidata-TekGen (10 topics)

Raw TekGen gold is distant supervision (most gold facts are not stated in the sentence), so only the clean subsets are
used: *verified* (manually verified, 250 sentences / 392 facts) and *unseen* (author-written, not on the web:
contamination-free, 170 / 170).

| Model | Subset | OntoLab | Direct | Δ F1 [CI] | p | Δ recall (p) |
|---|---|---|---|---|---|---|
| Haiku | verified | 0.410 | 0.431 | −0.02 [−0.11, +0.05] | 0.60 | −0.04 (0.24) |
| Haiku | unseen | 0.300 | 0.357 | −0.06 [−0.10, −0.02] | 0.003 | −0.08 (0.003) |
| Luna | verified | 0.270 | 0.415 | −0.15 [−0.34, +0.03] | 0.11 | −0.25 (0.015) |
| Luna | unseen | 0.299 | 0.349 | −0.05 [−0.11, +0.02] | 0.15 | −0.12 (0.001) |

**The DBpedia gain does not transfer to TekGen**, for both models: OntoLab loses recall and precision is about equal.
With Luna, three verified topics are nearly empty (movie 6 facts vs 103 direct, military 3 vs 43, space 0 vs 23; the
PR #45 retry fires only on a completely empty answer). Other misses: gold facts still not stated in the text, date
formats ("01 January 1999" vs "1999-01-01"; a lenient date normaliser for *both* systems is a to-do).
Gemini was not run on TekGen (no agy for new runs).

## 3. Alignment: OAEI Conference ra1-M3 (21 pairs, `28-stats-oaei.md`)

| System | F1 (run 1) | runs: mean (sd) | Δ vs edna, run 1 [CI] |
|---|---|---|---|
| OntoLab + Gemini verification | 0.742 | 1 run | +0.14 [+0.10, +0.18] |
| OntoLab + Haiku verification | 0.688 | 0.702 (0.013), 3 runs | +0.09 [+0.04, +0.14] (r2 +0.12, r3 +0.11) |
| OntoLab + Luna verification | 0.653 | 0.656 (0.009), 3 runs | +0.05 [+0.00, +0.11] (r2 +0.05 n.s., r3 +0.07) |
| edna / StringEquiv (official baselines) | 0.599 / 0.556 | | |
| OntoLab model-free | 0.59 | | |

Robust across vendors and runs (8 of 9 verification runs significantly above edna). Verification is stable between
runs (sd ≈ 0.01). Still missing: comparison with LLM matchers from the OAEI 2023–2025 result pages
(`datasets/oaei-conference/results-*.html`).

## 4. Grounding (`results/27-grounding`, `28-stats-grounding.md`)

Injected wrong-object facts: OntoLab's own-citation NLI check catches +0.20 (Gemini) / +0.26 (Haiku) more at 5%
false alarms than checking the best sentence anywhere, AUROC +0.08, all p<0.001; 90–96% caught vs 51–64%.
Wrong subject / relation / number: no difference. Text2KGBench outputs contain almost no hallucination; errors are
mapping and name form. (Luna not run on this study.)

## 5. Ontology induction

**OLLM arXiv taxonomy, test split (fuzzy / continuous / graph F1):**

| Model | OntoLab (after pruning) | OLLM prompting baseline |
|---|---|---|
| Gemini | 0.795 / 0.487 / 0.650 | 0.798 / 0.508 / 0.728 |
| Haiku | 0.729 / 0.501 / 0.547 | 0.815 / 0.528 / 0.732 |
| Luna | 0.756 / 0.501 / 0.724 | 0.835 / 0.515 / 0.681 |

**Negative or mixed:** prompting is better on fuzzy and continuous F1 for all three; OntoLab is better on graph F1
only with Luna. One run each, no CIs (single taxonomy).

**CQ-driven generation (Lippolis et al., 3 domains × 15 CQs; aggregates only, `21-cqonto/SUMMARY-*.md`,
`28-stats-cqonto-xvendor.md`):** each system is scored only by judges from other vendors (self-preference control).

| System | coverage ('yes' share) | judges |
|---|---|---|
| OntoLab default (Gemini) | 0.77 | Terra, Sonnet |
| OntoLab n-ary (Gemini) | 0.83 (+0.07 vs default, p=0.23) | Terra, Sonnet |
| OntoLab Haiku | 0.88 | Gemini, Terra |
| OntoLab Luna | 0.87 | **Sonnet only** (Gemini judge needs agy; not run) |
| Ontogenia o1 (best published) | 1.00 | Gemini, Sonnet |
| other published systems | 0.71–0.87 | |

OntoLab n-ary and Haiku beat the weakest published (Llama) systems (p≈0.01–0.03), equal the GPT-4 / o1 memless ones,
and lose to Ontogenia o1 (p<0.001). Judge–expert agreement κ: Terra 0.34–0.35, Gemini 0.21–0.23, Sonnet 4.6 0.13–0.17;
expert–expert 0.57. The judges are too weak to support claims: **needs the human rating** (pack prepared locally, not in git).

## What a paper can claim today
- OntoLab raises extraction **precision** on Text2KGBench DBpedia for models of three vendors (F1 +0.15 / +0.05 / +0.07
  as mean over runs for Gemini / Haiku / Luna); the gain comes from schema-constrained extraction.
- Citation-anchored verification catches wrong-object errors much better than post-hoc grounding.
- OntoLab + LLM verification beats the OAEI Conference baselines for all three vendors, stably across runs.
- Not supported: held-out generalisation (negative on TekGen for Haiku and Luna), induction (negative / mixed),
  component attribution (ablation effects within run variance), comparison with published SOTA systems (not done).

## Pending
Human CQ rating; SOTA baselines from the literature (OAEI participants, Text2KGBench systems, EDC); lenient date
normaliser; why Luna under-extracts on some TekGen topics; LettrIA refined benchmark (access requested).

## Product fixes found by these runs (OntoLab repo)
PR #44 (merged): proposed-facts folding, tokenizer-load retry. PR #45 (open): retry an empty extraction once.
PR #47 (open): count Claude prompt-cache writes as input tokens (found while preparing the cost table).
PR #46 (open): classify failed CLI calls by the CLI's error fields; dropped connections were reported as
"needs authentication" (`credential_expires_at` matched the login pattern) and stopped whole runs.

## Manuscript revision and new comparison (2026-11-21)

- **Two-pass Haiku baseline.** The document-level relation-enum and self-review prompt gives whole-graph
  lenient F1 0.575 and official per-sentence F1 0.42. The corresponding original OntoLab run is
  0.561 / 0.19. The paired whole-graph F1 difference (OntoLab minus baseline) is −0.014, 95% CI
  [−0.054, +0.025]. The baseline uses 17,308 output tokens per topic versus 13,656 for the
  saved OntoLab run. Input accounting is incomplete for the original Haiku results.
- **Grounding.** The topic-clustered replay supersedes the fact-level intervals for manuscript claims.
  At approximately 5% false alarms, Gemini catches 92% versus 72% and Haiku 96% versus 70%, with
  topic-clustered differences of +0.20 [0.10, 0.38] and +0.26 [0.10, 0.38].
- **Sentence coverage.** The Haiku pipeline emits predictions for 306 of 469 benchmark sentences versus
  463 for sentence prompting. Of its 211 strict unique true positives, 210 are assigned to at least
  one gold sentence.
- **Dates and alignment.** Unambiguous full-date normalisation changes verified TekGen F1 by no more
  than 0.003 and leaves unseen F1 unchanged. Six of seven stored alignment runs have an unadjusted
  interval above zero against edna. The public-reference comparison is separate from the blind ranking.

Sources — [baseline](results/36-stats-document-review.md), [grounding](results/36-stats-grounding-topics.md),
[extraction diagnostics](results/36-audit-extraction.md).
