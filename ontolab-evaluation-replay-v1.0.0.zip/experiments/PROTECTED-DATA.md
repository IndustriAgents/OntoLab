# Protected data: what must never be committed

## Lippolis et al. (ESWC 2025) ontology-generation benchmark
Source: https://github.com/dersuchendee/Onto-Generation. The gold data is distributed in a password-protected archive
"to prevent LLMs from including this dataset in their training data". We honour that:

- **Never commit or upload** the stories, competency questions (CQs), gold/expert labels, the published ontologies
  from that repo, OntoLab's ontologies induced from those stories, raw judge verdict files, the pitfall scan of the
  published ontologies, or the human-rating pack (`human-rating/`). That covers `tracks/cqonto/`, `datasets/cqonto/`,
  `results/21-cqonto/**` (except the SUMMARY tables) and `results/21-cqonto-published-pitfalls.json`.
- **Allowed in git:** aggregate tables (`results/21-cqonto/SUMMARY-*.md`, `results/28-stats-cqonto*.md`): coverage
  per system and domain, κ values, CIs. No CQ text, no story text, no ontology content.
- Logs record per-CQ verdict strings (`yyymy…`) and file names only; that is allowed.
- Do not paste CQs or stories into LLM web chats, issue trackers or shared docs. Running the benchmark through the
  model CLIs (as the experiments do) is what the original authors' setup also does.

How to get the data: ask the authors / follow the instructions in their repo, then put the checkout in
`datasets/cqonto/lippolis` and run `.venv/bin/python -I converters/cqonto_prepare.py datasets/cqonto/lippolis tracks/cqonto`.

Guards: `.gitignore` excludes the paths above; `sync_from_workdir.sh` never copies them and aborts if a summary
starts to contain question sentences. Before every push, also run:

    git ls-files | grep -iE 'cqonto|human-rating' | grep -vE 'SUMMARY-|28-stats-cqonto|converters/'

It must print nothing.

## Text2KGBench-LettrIA
Not obtained yet (request draft in `docs/LETTRIA-REQUEST-DRAFT.md`). If granted: local only, no redistribution.

## Everything else
Text2KGBench, OAEI Conference, MSE, OLLM arXiv and ContractNLI are public; they are still not committed (size, licences),
`setup.sh` downloads them at pinned versions with SHA-256 checks.
