# OntoLab code under test

Runs never use the public repo directly. Each runner imports one of five local copies, rebuilt by `setup.sh` from a
pinned commit of [IndustriAgents/OntoLab](https://github.com/IndustriAgents/OntoLab) plus a patch in `patches/`.
Outside `server/` the copies equal their base commit (checked 2026-11-21; only tests and `.env.example` differ).

| Copy | Base | Patch | What it is | Used by (runner → results; approximate, the `run_queueN.sh` that produced a result names its copy) |
|---|---|---|---|---|
| `ontolab-src` | `3e8ce2b` (PR #40) | `ontolab-src-3e8ce2b-local.diff` | First pinned clone + two bug fixes found by the experiments (OAEI reference loader read 0 cells; local NLI scored every pair 0.89) + CLI catalog/invoke allowlist | `align_eval`, `t2kb_extract`, `t2kb_direct` (the **direct-prompt baseline** everywhere), `contractnli_eval`, grid 06; results 01–08, 12, 15, 16 |
| `ontolab-fixed` | `3e8ce2b` | `ontolab-fixed-3e8ce2b-local.diff` | Fix-candidate branch (diff also in `patches/fixes-branch.diff`) | `t2kb_extract_fixed`, `contractnli_fulldoc`; results 09–11, 14 |
| `ontolab-v3` | `3931d33` (main after PR #44) | `ontolab-v3-vs-3931d33.server.diff` | feat/benchmark-improvements before the proposed-facts fix (prompt v11) | `t2kb_extract_v3`, `align_eval_v3`, `ollm_*`, `cqonto_*`, grounding; results 17–21, 27; also hosts `node_modules` and the model cache for v4/v5 |
| `ontolab-v4` | `3931d33` | `ontolab-v4-vs-3931d33.server.diff` | ≈ main + `EVAL_REASONING_EFFORT` + PR #45 (empty-extraction retry) | `t2kb_extract_v4`; results 23 (`t2kb-ontolab-v4`), 24, 34-haiku, 35-luna |
| `ontolab-v5` | `3931d33` | `ontolab-v5-vs-3931d33.server.diff` | main + `EVAL_REASONING_EFFORT` + PR #45 | CQ induction for Luna (`ONTOLAB_ROOT=../ontolab-v5`, queue 16) and the n-ary CQ runs |

Experiment-only patch (never upstream): `server/cli/invoke.ts` reads `EVAL_REASONING_EFFORT` so the codex CLI gets
`model_reasoning_effort` when a benchmark runner passes no per-request effort.

Product fixes that came out of the experiments (all upstream):
- PR #44 (merged, `3931d33`): proposed-facts folding (Haiku filed ordinary facts as new terms), tokenizer-load retry
  (silent hash-embedder fallback), benchmark improvements.
- PR #45 (**open**): retry an empty extraction once and say so in the notes (GPT-6 Luna returned empty extractions at random).
  The v4/v5 copies already contain it; results 34/35 depend on it.

Models and CLIs: Gemini 3.8 Flash low (`gemini-3.8-flash-low`, all tested Gemini runs) and medium (CQ judge only) via `agy`
(Antigravity CLI 1.5.12–1.5.13); Claude Haiku = `claude-haiku-5-5` (CLI default effort; Claude Code 2.1.330 installed at the end of the runs) and
Sonnet 4.6 via the `claude` CLI (pass `claude-sonnet-4-6` explicitly: the alias `sonnet` is Sonnet 5.5); GPT-6 Luna
and GPT-6.1 Terra (both medium effort) via the `codex` CLI (0.170.0 at the end of the runs). Node 22.23.5, Python 3.12.8 (`requirements.lock.txt`).
Embedder `Xenova/all-MiniLM-L6-v2` (q8), NLI `Xenova/nli-deberta-v3-xsmall` (q8), loaded offline (`converters/offline-models.mts`).
