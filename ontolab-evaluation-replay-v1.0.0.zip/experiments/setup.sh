#!/bin/bash
# Re-create everything the experiment scripts need that is NOT in git:
#   datasets/   public benchmarks (pinned clones, checksum-verified downloads)
#   tracks/     benchmark inputs in OntoLab's format (generated from datasets/)
#   ontolab-*/  the OntoLab code copies the runs used (pinned commit + patches/, see ONTOLAB_VERSION.md)
#   .venv/      Python environment (requirements.lock.txt)
# Idempotent: existing pieces are kept. Run from anywhere: experiments/setup.sh
#
# Needs: git, curl, unzip, Node 22.23.5 (nvm), Python 3.12, an OntoLab checkout with history
# (ONTOLAB_REPO, default: clone of github.com/IndustriAgents/OntoLab).
# The Lippolis et al. CQ data is password-protected and NOT set up here: see PROTECTED-DATA.md.
set -euo pipefail
E=$(cd "$(dirname "$0")" && pwd); cd "$E"
ONTOLAB_REPO=${ONTOLAB_REPO:-https://github.com/IndustriAgents/OntoLab.git}
export PATH=$HOME/.nvm/versions/node/v22.23.5/bin:$PATH
say() { printf '\n== %s\n' "$*"; }
verify() { echo "$2  $1" | shasum -a 256 -c - >/dev/null || { echo "CHECKSUM MISMATCH: $1 (results were computed on a different file)" >&2; exit 1; }; }
clone_at() { [ -d "$2/.git" ] || git clone -q "$1" "$2"; git -C "$2" fetch -q --depth 1 origin "$3" 2>/dev/null || true; git -C "$2" checkout -q "$3"; }

say "Python environment"
[ -d .venv ] || python3.12 -m venv .venv
.venv/bin/pip install -q -r requirements.lock.txt

say "Datasets"
mkdir -p datasets/{text2kgbench,mse,ollm/arxiv/train_test_split,ollm/arxiv/train_eval_split,oaei-conference,contractnli}
clone_at https://github.com/cenguix/Text2KGBench.git datasets/text2kgbench/repo 50a3d25
clone_at https://github.com/EngyNasr/MSE-Benchmark.git datasets/mse/repo 50abe77
clone_at https://github.com/andylolu2/ollm.git datasets/ollm/repo 3904977
HF=https://huggingface.co/datasets/andylolu24/arxiv-ol/resolve/main
for f in train_test_split/test_graph.json train_test_split/train_graph.json train_eval_split/test_graph.json; do
  [ -s datasets/ollm/arxiv/$f ] || curl -sSL -o datasets/ollm/arxiv/$f $HF/$f
done
verify datasets/ollm/arxiv/train_test_split/test_graph.json 18e6c811bd70bd9061749bd57e90c924b30e474afb96dfad7a80a5d5198a7e2f
verify datasets/ollm/arxiv/train_test_split/train_graph.json 5407a77950c068ddef4845cd5a479020eb497a7c5935e6cf5465718c7f37ee08
verify datasets/ollm/arxiv/train_eval_split/test_graph.json 82543d80fe97e424e46006a7dd2938db197ac59662aef220b3b8d4bcd150f1e2
C=datasets/oaei-conference
[ -s $C/conference.zip ] || curl -sSL -o $C/conference.zip https://oaei.ontologymatching.org/2023/conference/data/conference.zip
[ -s $C/ra.zip ] || curl -sSL -o $C/ra.zip https://oaei.ontologymatching.org/2023/conference/data/reference-alignment.zip
verify $C/conference.zip 78688cda05857b594be188db6831abc5d890d2e38d6602e0cd8d3c82ecb24546
verify $C/ra.zip 782e0175253d817288e1f7ed29f738a7fa9e57a8b9c77bb3b11c12b80405d4bf
[ -d $C/raw ] || { mkdir -p $C/raw $C/ref; unzip -qo $C/conference.zip -d $C/raw; unzip -qo $C/ra.zip -d $C/ref; }
echo "  check: $C/raw holds the *.owl files and $C/ref the 21 *.rdf reference alignments (flatten if the zips nest folders)"
[ -s datasets/contractnli/contract-nli.zip ] || curl -sSL -o datasets/contractnli/contract-nli.zip https://stanfordnlp.github.io/contract-nli/resources/contract-nli.zip
verify datasets/contractnli/contract-nli.zip e03fc77bbf8b53e2976a250e81d8a294bc3d5e5fb014521e477dee9340d6287b
[ -d datasets/contractnli/raw ] || unzip -qo datasets/contractnli/contract-nli.zip -d datasets/contractnli/raw

say "Tracks (benchmark inputs in OntoLab format)"
P=".venv/bin/python -I"
[ -d tracks/t2kb ] || $P converters/t2kb_prepare.py datasets/text2kgbench/repo/data tracks/t2kb 25
for sel in verified unseen; do
  [ -d tracks/tekgen-$sel ] || T2KB_SUBSET=wikidata_tekgen T2KB_SELECT=$sel $P converters/t2kb_prepare.py datasets/text2kgbench/repo/data tracks/tekgen-$sel 25
done
[ -d tracks/conference ] || bash converters/prep_oaei.sh
[ -d tracks/ollm ] || $P converters/ollm_sample.py datasets/ollm/arxiv tracks/ollm 5 13

say "OntoLab code copies (see ONTOLAB_VERSION.md)"
[ -d ontolab-repo/.git ] || git clone -q "$ONTOLAB_REPO" ontolab-repo
git -C ontolab-repo fetch -q origin
mk_copy() { # <dir> <commit> <patch...>
  local d=$1 c=$2; shift 2
  [ -d "$d" ] && return
  mkdir -p "$d"; git -C ontolab-repo archive "$c" | tar -x -C "$d"
  for p in "$@"; do (cd "$d" && patch -s -p1 < "$E/patches/$p"); done
}
mk_copy ontolab-v3 3931d33 ontolab-v3-vs-3931d33.server.diff
mk_copy ontolab-v4 3931d33 ontolab-v4-vs-3931d33.server.diff
mk_copy ontolab-v5 3931d33 ontolab-v5-vs-3931d33.server.diff
mk_copy ontolab-src 3e8ce2b ontolab-src-3e8ce2b-local.diff
mk_copy ontolab-fixed 3e8ce2b ontolab-fixed-3e8ce2b-local.diff
[ -d ontolab-v3/node_modules ] || (cd ontolab-v3 && npm ci --silent)
for d in ontolab-v4 ontolab-v5; do [ -e $d/node_modules ] || ln -s ../ontolab-v3/node_modules $d/node_modules; done
for d in ontolab-src ontolab-fixed; do [ -d $d/node_modules ] || (cd $d && npm ci --silent); done

say "Model cache (the runners forbid downloads: converters/offline-models.mts)"
mkdir -p ontolab-v3/.data/models
(cd ontolab-v3 && node --input-type=module -e '
const T = await import("@huggingface/transformers");
T.env.cacheDir = ".data/models";
await T.pipeline("feature-extraction", "Xenova/all-MiniLM-L6-v2", { dtype: "q8" });
await T.AutoTokenizer.from_pretrained("Xenova/all-MiniLM-L6-v2");
await T.AutoModelForSequenceClassification.from_pretrained("Xenova/nli-deberta-v3-xsmall", { dtype: "q8" });
console.log("models cached");')

say "Done"
echo "Scripts in converters/ use the absolute work-dir path of the original machine; run converters in this"
echo "directory after:  grep -rl /Users/mx/Documents/Work/industriAgents/experiments/ontolab converters | xargs sed -i '' \"s#/Users/mx/Documents/Work/industriAgents/experiments/ontolab#$E#g\""
echo "Model access: LOCAL_CLI_ENABLED=1 with the agy / claude / codex CLIs signed in (see README.md)."
