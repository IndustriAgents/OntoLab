import { readFile, writeFile, mkdtemp, rm } from "node:fs/promises";
import { join, resolve } from "node:path";
import { tmpdir } from "node:os";
import { fileURLToPath, pathToFileURL } from "node:url";
import { createHash } from "node:crypto";

const checkout = process.argv[2];
if (!checkout) throw new Error("Usage: tsx commit-example.mts /path/to/ontolab-v4");
const folder = fileURLToPath(new URL("./", import.meta.url));
const load = (path: string) => import(pathToFileURL(resolve(checkout, path)).href);
const { createLocalStore } = await load("server/store/local.ts");
const { silentLogger } = await load("server/services/context.ts");
const { createProject } = await load("server/services/projects.ts");
const { createRevision, updateDraft, commitRevision, requireRevision } = await load("server/services/revisions.ts");
const { tboxOf } = await load("server/services/ontology.ts");
const { applyDecisions, factKey, effectiveAbox } = await load("src/lib/ontology/factReview.ts");
const { serializeABox } = await load("src/lib/ontology/aboxSerializer.ts");
const { locateQuote } = await load("src/lib/sourceQuote.ts");
const base = "https://w3id.org/ontolab/citation-review/usgs#";
const parsed = JSON.parse(await readFile(join(folder, "proposals.json"), "utf8"));
const source = await readFile(join(folder, "source.txt"), "utf8");
if (createHash("sha256").update(source).digest("hex") !== parsed.source_sha256) throw new Error("Source snapshot changed");
const ontology = await readFile(join(folder, "ontology.ttl"), "utf8");
const assertions = parsed.assertions;
const keyIds = ["ph-sensor", "ph-measurement"];
const classes = ["Instrument", "Measurement"];
const draft = { individuals: assertions.map((a, i) => ({
  id: keyIds[i],
  label: a.subject,
  classUri: base + classes[i],
  dataProperties: [{ propUri: a.propertyUri, value: a.object, datatype: "http://www.w3.org/2001/XMLSchema#string",
    evidence: a.evidence.map((e) => {
      const span = locateQuote(e.quote, source);
      if (!span || span.start !== e.start || span.end !== e.end) throw new Error("Evidence offsets do not resolve");
      return e;
    }),
    review: { ...a.review, status: "candidate" } }],
})) };
const dataDir = await mkdtemp(join(tmpdir(), "ontolab-curation-example-"));
try {
  const user = { id: "example" };
  const ctx = { user, store: createLocalStore(dataDir).forUser(user), log: silentLogger, now: () => new Date(), requestId: "example" };
  const project = await createProject(ctx, { name: "USGS pH evidence review", purpose: "Demonstrate source-backed review", scope: "" });
  const content = { abox: draft, baseIri: base, modules: [{ id: "usgs-schema", name: "ontology.ttl", turtle: ontology }] };
  const revision = await createRevision(ctx, project.id, { content, source: "import", summary: "Two actual extraction proposals" });
  const before = await requireRevision(ctx, project.id, revision.id);
  const decisions = assertions.map((a, i) => ({
    key: factKey(keyIds[i], "data", draft.individuals[i].dataProperties[0]), status: a.decision, reason: a.reason,
  }));
  const reviewed = applyDecisions(before.content.abox, decisions, "2026-11-21T00:00:00.000Z");
  if (reviewed.applied !== 2) throw new Error("Expected two explicit decisions");
  const updated = await updateDraft(ctx, project.id, revision.id, { ...before.content, abox: reviewed.abox }, "Review pH specifications");
  await commitRevision(ctx, project.id, revision.id, updated.contentHash);
  const committed = await requireRevision(ctx, project.id, revision.id);
  if (committed.status !== "committed") throw new Error("Graph version was not committed");
  const tbox = tboxOf(committed.content);
  const accepted = effectiveAbox(committed.content.abox, "accepted-only");
  const { turtle } = serializeABox(accepted, tbox, base, { provenance: "reified" });
  await writeFile(join(folder, "reviewed.ttl"), turtle);
  await writeFile(join(folder, "review-log.json"), JSON.stringify({ commitStatus: committed.status,
    contentHash: committed.contentHash, decisions }, null, 2) + "\n");
} finally {
  await rm(dataDir, { recursive: true, force: true });
}
