# Review pH specifications from a real source

This walkthrough uses two actual relation proposals from an OntoLab extraction on chapter A6.8 of the U.S. Geological Survey National Field Manual. The publication is [Use of Multiparameter Instruments for Routine Field Measurements](https://doi.org/10.3133/tm9A6.8). The excerpt in `source.txt` is the parser output used for source offsets. Credit U.S. Geological Survey.

| Proposal | Recorded quote | Decision |
|---|---|---|
| pH sensor has accuracy ±0.1 pH units | Accuracy, ±0.1 pH units. | Accept. The table entry under pH and millivolt specifies this accuracy. |
| pH measurement has reporting precision ±0.01 pH units | Resolution, ±0.01 pH units. | Reject. Instrument resolution alone does not establish reporting precision. |

The local entailment scores were 0.014 and 0.370 respectively. The source context and the meaning of the properties determine these illustrative decisions. They were scripted for this walkthrough, separate from the independent reviewer study.

`commit-example.mts` imports the two recorded proposals, checks their source offsets, applies the decisions, commits a graph revision through OntoLab's revision service and exports the accepted facts using OntoLab's full-provenance RDF serializer. Run it with the `tsx` frontend of the paper's v4 dependency snapshot and pass the snapshot directory as the only argument. The script writes `reviewed.ttl` and `review-log.json`.

Run `evidence.rq` over `reviewed.ttl` to retrieve the accepted accuracy statement, recorded quote, source offsets, confidence and review status. The rejection and its rationale are retained in the review log. The rejected reporting precision statement is excluded from the effective graph.
