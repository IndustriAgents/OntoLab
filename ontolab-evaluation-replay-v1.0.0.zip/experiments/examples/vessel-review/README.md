# Review a misassigned pressure

This synthetic maintenance note illustrates one curation task. The supplied Turtle draft contains a deliberate error, and the TSV records the evidence a curator uses to resolve it.

1. Create a project in [OntoLab](https://github.com/IndustriAgents/OntoLab). Import the ontology and upload the maintenance note. Run extraction with citations if a model is available, then open **Knowledge graphs → Explore → Review facts**.
2. Use the provided draft to repeat the exercise without a model. Import it as A-Box data or enter the two vessels and their four assertions in Explore. The TSV supplies the source passages for the manual exercise. If you ran extraction, use **Inspect evidence** to see which passages it actually found.
3. Compare V-101’s design pressure with the V-101 sentence. Reject or edit the incorrect 8 bar proposal and accept the corrected 12 bar assertion. Check V-202 and both operating pressures, then rerun validation and commit.
4. From the committed graph choose **Export graph → Individuals only → Facts only**. The expected Turtle graph lists the four reviewed values. Prefixes, generated IRIs and Turtle layout may differ. For a model-backed project that has recorded evidence, choose **Full provenance (PROV-O)** to inspect the assertion and evidence metadata.

The example source, ontology and expected decisions are authored fixtures. The text specifies design and operating pressure independently. Domain and datatype validation can allow both 8 and 12 as decimals, so the error is visible only when checking the assertion against the relevant evidence.
